import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function json(error: string, message: string, status: number) {
  return NextResponse.json({ ok: false, error, message }, { status });
}

function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

function isStrongPassword(value: string) {
  return (
    value.length >= 10 &&
    value.length <= 128 &&
    /[A-Z]/.test(value) &&
    /[a-z]/.test(value) &&
    /[0-9]/.test(value) &&
    /[^A-Za-z0-9]/.test(value)
  );
}

async function verifyTurnstile(token: string, ip?: string) {
  const secret = process.env.TURNSTILE_SECRET_KEY;

  if (!secret) {
    console.error("Missing TURNSTILE_SECRET_KEY");
    return false;
  }

  const formData = new FormData();
  formData.append("secret", secret);
  formData.append("response", token);

  if (ip) {
    formData.append("remoteip", ip);
  }

  const res = await fetch(
    "https://challenges.cloudflare.com/turnstile/v0/siteverify",
    {
      method: "POST",
      body: formData,
    }
  );

  if (!res.ok) {
    console.error("Turnstile verify HTTP error:", res.status);
    return false;
  }

  const data = (await res.json()) as {
    success?: boolean;
    "error-codes"?: string[];
  };

  if (!data.success) {
    console.error("Turnstile failed:", data["error-codes"]);
  }

  return data.success === true;
}

export async function POST(req: Request) {
  try {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      return json("server_config", "Server is not configured.", 500);
    }

    const body = (await req.json().catch(() => null)) as {
      email?: string;
      password?: string;
      token?: string;
    } | null;

    const email = String(body?.email || "").trim().toLowerCase();
    const password = String(body?.password || "");
    const token = String(body?.token || "");

    if (!token || !isValidEmail(email) || !isStrongPassword(password)) {
      return json(
        "invalid_request",
        "Password must have 10+ characters, uppercase, lowercase, number and symbol.",
        400
      );
    }

    const ip =
      req.headers.get("cf-connecting-ip") ||
      req.headers.get("x-forwarded-for")?.split(",")[0]?.trim();

    const captchaOk = await verifyTurnstile(token, ip);

    if (!captchaOk) {
      return json("captcha_failed", "Captcha failed. Please try again.", 400);
    }

    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });

    const siteUrl =
      process.env.NEXT_PUBLIC_SITE_URL ||
      process.env.NEXT_PUBLIC_APP_URL ||
      "http://localhost:3000";

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${siteUrl}/auth/callback`,
      },
    });

    if (error) {
      const message = error.message.toLowerCase();

      if (
        message.includes("already") ||
        message.includes("registered") ||
        message.includes("exists")
      ) {
        return json("email_exists", "User already exists. Try logging in.", 409);
      }

      return json("signup_failed", error.message || "Signup failed.", 400);
    }

    return NextResponse.json(
      {
        ok: true,
        userId: data.user?.id ?? null,
        message: "Account created. We sent you a verification email.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Signup API error:", error);
    return json("server_error", "Server error.", 500);
  }
}