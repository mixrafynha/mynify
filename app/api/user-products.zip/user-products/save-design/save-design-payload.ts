import type { createSupabaseServer } from "@/lib/supabase-server";
import {
  buildR2DesignKey,
  cleanDataUrls,
  dataUrlToBuffer,
  isDataImage,
  sideValue,
} from "./image-utils";
import type { DesignAssetKind, DesignSide } from "./image-utils";
import { uploadBufferToR2, type R2UploadResult } from "./r2";

export function isUuid(value: unknown) {
  return (
    typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value)
  );
}

function parseJsonIfString<T>(value: unknown, fallback: T): T {
  if (typeof value !== "string") {
    return (value ?? fallback) as T;
  }

  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function arrayValue(value: unknown) {
  const parsed = parseJsonIfString<unknown>(value, value);
  return Array.isArray(parsed) ? parsed : [];
}

function objectValue<T extends Record<string, unknown>>(value: unknown, fallback: T): T {
  const parsed = parseJsonIfString<unknown>(value, value);
  return parsed && typeof parsed === "object" && !Array.isArray(parsed)
    ? (parsed as T)
    : fallback;
}

type UploadDesignImageArgs = {
  userId: string;
  designId: string;
  side: DesignSide;
  kind: DesignAssetKind;
  dataUrl: unknown;
};

export async function uploadDesignImageToR2(
  args: UploadDesignImageArgs,
): Promise<R2UploadResult> {
  if (!isDataImage(args.dataUrl)) {
    return { key: null, url: null };
  }

  const { buffer, mimeType, extension } = dataUrlToBuffer(args.dataUrl);
  const key = buildR2DesignKey({
    userId: args.userId,
    designId: args.designId,
    kind: args.kind,
    side: args.side,
    extension,
  });

  return uploadBufferToR2({
    key,
    buffer,
    contentType: mimeType,
  });
}

export async function getBaseProduct(args: {
  supabase: ReturnType<typeof createSupabaseServer>;
  baseProductId: string;
}) {
  let productQuery = args.supabase
    .from("products")
    .select(`
      id,
      title,
      description,
      price,
      currency,
      image,
      images,
      category,
      slug
    `);

  productQuery = isUuid(args.baseProductId)
    ? productQuery.eq("id", args.baseProductId)
    : productQuery.or(`slug.eq.${args.baseProductId},category.eq.${args.baseProductId}`);

  const { data, error } = await productQuery.maybeSingle();

  if (error || !data) {
    return {
      baseProduct: null,
      productError: error || new Error("Base product not found"),
    };
  }

  return { baseProduct: data, productError: null };
}

export async function buildUserProductSavePayload(args: {
  body: any;
  userId: string;
  designId: string;
  baseProduct: any;
}) {
  const { body, userId, designId, baseProduct } = args;

  const incomingDesignData = objectValue<any>(body.design_data, {});
  const incomingPrintFiles = objectValue<any>(body.printFiles || body.print_files, {});
  const incomingMockups = objectValue<any>(body.mockups, {});
  const incomingSides = objectValue<any>(body.sides || incomingDesignData.sides, {});

  const frontElements = arrayValue(
    body.designFront || body.design_front || incomingSides?.front?.elements,
  );
  const backElements = arrayValue(
    body.designBack || body.design_back || incomingSides?.back?.elements,
  );

  const frontDesignImage =
    incomingSides?.front?.designImage || incomingDesignData?.sides?.front?.designImage;
  const backDesignImage =
    incomingSides?.back?.designImage || incomingDesignData?.sides?.back?.designImage;

  const printFront = await uploadDesignImageToR2({
    userId,
    designId,
    side: "front",
    kind: "print",
    dataUrl:
      sideValue(incomingPrintFiles, "front") ||
      frontDesignImage,
  });

  const printBack = await uploadDesignImageToR2({
    userId,
    designId,
    side: "back",
    kind: "print",
    dataUrl:
      sideValue(incomingPrintFiles, "back") ||
      backDesignImage,
  });

  const mockupFront = await uploadDesignImageToR2({
    userId,
    designId,
    side: "front",
    kind: "mockups",
    dataUrl: sideValue(incomingMockups, "front"),
  });

  const mockupBack = await uploadDesignImageToR2({
    userId,
    designId,
    side: "back",
    kind: "mockups",
    dataUrl: sideValue(incomingMockups, "back"),
  });

  const editorFront = await uploadDesignImageToR2({
    userId,
    designId,
    side: "front",
    kind: "editor",
    dataUrl: frontDesignImage,
  });

  const editorBack = await uploadDesignImageToR2({
    userId,
    designId,
    side: "back",
    kind: "editor",
    dataUrl: backDesignImage,
  });

  const productMarkup = Number(body.markup || 0);
  const basePrice = Number(baseProduct.price || 0);
  const finalPrice = basePrice + productMarkup;

  const printBox = objectValue<any>(body.printBox || body.print_box, {
    front: incomingSides?.front?.printBox || incomingDesignData?.sides?.front?.printBox || null,
    back: incomingSides?.back?.printBox || incomingDesignData?.sides?.back?.printBox || null,
  });

  const safeArea = objectValue<any>(body.safeArea || body.safe_area, {
    front: incomingSides?.front?.safeArea || incomingDesignData?.sides?.front?.safeArea || null,
    back: incomingSides?.back?.safeArea || incomingDesignData?.sides?.back?.safeArea || null,
  });

  const designData = cleanDataUrls({
    schemaVersion: body.schemaVersion || incomingDesignData.schemaVersion || 4,
    productId: baseProduct.id,
    category: baseProduct.category || body.category || incomingDesignData.category || null,
    color: body.color || body.mockupColor || incomingDesignData.color || null,
    mockupColor: body.mockupColor || body.color || incomingDesignData.mockupColor || null,
    selectedColor:
      body.selectedColor || body.selected_color || incomingDesignData.selectedColor || null,
    selectedVariant:
      body.selectedVariant || body.selected_variant || incomingDesignData.selectedVariant || null,
    status: body.status || incomingDesignData.status || "draft",
    sides: {
      front: {
        ...(incomingDesignData?.sides?.front || {}),
        side: "front",
        elements: frontElements,
        printBox: printBox.front || null,
        safeArea: safeArea.front || null,
        designImage: null,
        designImageUrl: editorFront.url || null,
        editorFileUrl: editorFront.url || null,
        printFileUrl: printFront.url || null,
        mockupUrl: mockupFront.url || null,
      },
      back: {
        ...(incomingDesignData?.sides?.back || {}),
        side: "back",
        elements: backElements,
        printBox: printBox.back || null,
        safeArea: safeArea.back || null,
        designImage: null,
        designImageUrl: editorBack.url || null,
        editorFileUrl: editorBack.url || null,
        printFileUrl: printBack.url || null,
        mockupUrl: mockupBack.url || null,
      },
    },
    production: incomingDesignData.production || body.production || null,
  }) as any;

  const bestPreviewImage =
    mockupFront.url ||
    editorFront.url ||
    printFront.url ||
    mockupBack.url ||
    editorBack.url ||
    printBack.url ||
    baseProduct.image ||
    null;

  const baseImages = Array.isArray(baseProduct.images) ? baseProduct.images : [];

  return {
    id: designId,
    user_id: userId,
    base_product_id: baseProduct.id,
    title: body.title || baseProduct.title,
    description: body.description ?? baseProduct.description ?? null,
    price: basePrice,
    currency: baseProduct.currency || "USD",
    image: bestPreviewImage,
    images: [
      mockupFront.url,
      mockupBack.url,
      editorFront.url,
      editorBack.url,
      printFront.url,
      printBack.url,
      ...baseImages,
    ].filter(Boolean),
    category: baseProduct.category || body.category || null,
    slug: `${baseProduct.slug || "product"}-${designId.slice(0, 8)}`,
    design_front: frontElements,
    design_back: backElements,
    design_data: designData,
    print_files: {
      front: printFront.url,
      back: printBack.url,
      keys: {
        front: printFront.key,
        back: printBack.key,
      },
    },
    mockups: {
      front: mockupFront.url,
      back: mockupBack.url,
      keys: {
        front: mockupFront.key,
        back: mockupBack.key,
      },
    },
    print_box: printBox,
    safe_area: safeArea,
    design_image_url: editorFront.url || editorBack.url || null,
    ai_mockup_url: mockupFront.url || mockupBack.url || null,
    ai_mockup_images: [mockupFront.url, mockupBack.url].filter(Boolean),
    markup: productMarkup,
    final_price: finalPrice,
    status: body.status || "draft",
    cart_status: body.cartStatus || body.cart_status || "in_cart",
    is_active: true,
    design_version: body.schemaVersion || incomingDesignData.schemaVersion || 4,
    updated_at: new Date().toISOString(),
  };
}
