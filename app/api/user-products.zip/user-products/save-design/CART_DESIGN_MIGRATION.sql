-- Optional but recommended for custom POD designs in cart_items.
-- The API works without this migration, but without these columns the cart cannot link
-- each row back to the exact saved user_products design.

alter table public.cart_items
add column if not exists user_product_id uuid null references public.user_products(id) on delete cascade,
add column if not exists design_id uuid null references public.user_products(id) on delete cascade,
add column if not exists item_type text null default 'product';

create index if not exists cart_items_user_product_id_idx
on public.cart_items(user_product_id);

create index if not exists cart_items_design_id_idx
on public.cart_items(design_id);

create index if not exists cart_items_user_design_idx
on public.cart_items(user_id, design_id);
