import type { createSupabaseServer } from "@/lib/supabase-server";

type SupabaseServer = ReturnType<typeof createSupabaseServer>;

type AddSavedDesignToCartArgs = {
  supabase: SupabaseServer;
  userId: string;
  userProduct: any;
  body: any;
};

function asNumber(value: unknown, fallback = 0) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function normalizeQuantity(value: unknown) {
  return Math.max(1, Math.floor(asNumber(value, 1)));
}

function isMissingColumnError(error: unknown) {
  const message =
    error && typeof error === "object" && "message" in error
      ? String((error as { message?: unknown }).message || "")
      : String(error || "");

  return (
    message.includes("column") ||
    message.includes("schema cache") ||
    message.includes("Could not find")
  );
}

export async function addSavedDesignToCart(args: AddSavedDesignToCartArgs) {
  const { supabase, userId, userProduct, body } = args;

  const quantity = normalizeQuantity(body.quantity);
  const variantId = body.variantId || body.variant_id || null;
  const selectedVariant = userProduct.design_data?.selectedVariant || null;
  const selectedColor = userProduct.design_data?.selectedColor || null;

  const title = userProduct.title;
  const price = asNumber(userProduct.final_price ?? userProduct.price, 0);
  const currency = userProduct.currency || "USD";
  const image =
    userProduct.ai_mockup_url ||
    userProduct.image ||
    userProduct.design_image_url ||
    userProduct.print_files?.front ||
    null;

  const color =
    body.color ||
    body.mockupColor ||
    selectedColor?.name ||
    selectedColor?.hex ||
    userProduct.design_data?.mockupColor ||
    null;

  const size = body.size || selectedVariant?.size || null;
  const sku = body.sku || selectedVariant?.sku || null;

  const extendedPayload = {
    user_id: userId,
    product_id: userProduct.base_product_id,
    user_product_id: userProduct.id,
    design_id: userProduct.id,
    variant_id: variantId,
    title,
    price,
    currency,
    quantity,
    image,
    color,
    size,
    sku,
    item_type: "custom_design",
  };

  const { data: extendedData, error: extendedError } = await supabase
    .from("cart_items")
    .insert(extendedPayload)
    .select()
    .single();

  if (!extendedError) {
    return { data: extendedData, error: null, mode: "extended" as const };
  }

  if (!isMissingColumnError(extendedError)) {
    return { data: null, error: extendedError, mode: "extended" as const };
  }

  const basicPayload = {
    user_id: userId,
    product_id: userProduct.base_product_id,
    variant_id: variantId,
    title,
    price,
    currency,
    quantity,
    image,
    color,
    size,
    sku,
  };

  const { data: basicData, error: basicError } = await supabase
    .from("cart_items")
    .insert(basicPayload)
    .select()
    .single();

  return {
    data: basicData,
    error: basicError,
    mode: "basic" as const,
  };
}
