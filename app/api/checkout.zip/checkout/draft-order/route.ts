import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { createSupabaseAdmin } from "@/lib/supabase-admin";
import { createSupabaseServer } from "@/lib/supabase-server";
import { buildGelatoCheckoutQuotePayload } from "@/lib/gelato/checkout-quote";
import { resolveCountryCode } from "@/lib/gelato/country-code-map";
import { getGelatoProduct, searchGelatoCatalogProducts, type GelatoCatalogSearchProduct, type GelatoProductDetails } from "@/lib/gelato/catalog-sync";
import { resolveGelatoPrintFiles, type CartItem, type CartVariant } from "@/app/checkout/_lib/checkout";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type DraftBody = {
  cartItemIds?: string[];
  address?: {
    firstName?: string;
    lastName?: string;
    fullName?: string;
email?: string;
    phone?: string;
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    state?: string;
    stateCode?: string;
    postalCode?: string;
    countryCode?: string;
  };
  shippingMethod?: {
    id: string;
    code?: string | null;
    shipmentMethodUid: string;
    name: string;
    price: number;
    currency: string;
  };
};

type CartRow = {
  id: string;
  user_id: string;
  product_id: string;
  variant_id: string | null;
  user_product_id: string | null;
  design_id: string | null;
  quantity: number | null;
  selected_variant: Record<string, unknown> | null;
  title: string;
};

type ProductRow = {
  id: string;
  gelato_product_uid: string | null;
  price: number | string | null;
};

type VariantRow = {
  id: string;
  sku: string | null;
  size: string | null;
  product_color_id: string | null;
  gelato_product_uid: string | null;
  price: number | string | null;
  name?: string | null;
};

type UserProductRow = {
  id: string;
  user_id: string | null;
  gelato_product_uid: string | null;
  price: number | string | null;
  markup: number | string | null;
  final_price: number | string | null;
  design_data: Record<string, unknown> | null;
  print_files: Record<string, unknown> | null;
  mockups: Record<string, unknown> | null;
};

type GelatoFile = { type: string; url: string };

type GelatoPrintAreaResolution = {
  productUid: string;
  currentPrintAreas: string[];
  resolvedPrintAreas: string[];
  catalogUid: string | null;
  catalogUidSource: "gelato_catalog_sync_state" | "product_api" | "not_needed" | "missing";
  resolvedFrom: "current" | "catalog_search";
};

type GelatoSyncStateRow = {
  product_id: string;
  catalog_uid: string | null;
};

const conflict = (
  code: string,
  message: string,
  details?: Record<string, unknown>,
) => {
  console.error("[checkout:draft-conflict]", {
    code,
    message,
    ...(details ?? {}),
  });

  return NextResponse.json(
    {
      success: false,
      code,
      message,
      details: details ?? null,
    },
    { status: 409 },
  );
};

function cleanText(value: unknown) {
  return typeof value === "string" ? value.trim() : "";
}

function splitFullName(fullName: string) {
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length < 2) return { firstName: parts[0] || "", lastName: "" };
  return { firstName: parts.slice(0, -1).join(" "), lastName: parts.at(-1) || "" };
}

function normalizeAddress(body: DraftBody) {
  const address = body.address ?? {};
  const fullName = cleanText(address.fullName);
  const split = splitFullName(fullName);
  const firstName = cleanText(address.firstName) || split.firstName;
  const lastName = cleanText(address.lastName) || split.lastName;
  const countryCode = (cleanText(address.countryCode) || "").toUpperCase();
  return {
    firstName,
    lastName,
    email: cleanText(address.email),
    phone: cleanText(address.phone),
    addressLine1: cleanText(address.addressLine1),
    addressLine2: cleanText(address.addressLine2) || undefined,
    city: cleanText(address.city),
    state: cleanText(address.stateCode) || cleanText(address.state) || undefined,
    stateCode: cleanText(address.stateCode) || undefined,
    postalCode: cleanText(address.postalCode),
    countryCode: resolveCountryCode(countryCode) ?? countryCode,
  };
}

function hashIdempotencyKey(input: Record<string, unknown>) {
  return createHash("sha256").update(JSON.stringify(input)).digest("hex");
}

function isUuid(value: unknown): value is string {
  return typeof value === "string" && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function extractBoolean(value: unknown) {
  return value === true || value === "true" || value === 1 || value === "1";
}

function firstString(...values: unknown[]) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function resolveVariantId(row: CartRow, userProduct: UserProductRow | null) {
  const selectedVariant = row.selected_variant && typeof row.selected_variant === "object" ? row.selected_variant : null;
  const designRecord =
    userProduct?.design_data && typeof userProduct.design_data === "object"
      ? (userProduct.design_data as Record<string, unknown>)
      : null;
  const selectedVariantRecord =
    designRecord && typeof designRecord["selectedVariant"] === "object"
      ? (designRecord["selectedVariant"] as Record<string, unknown>)
      : null;
  return firstString(
    row.variant_id,
    selectedVariant?.id,
    designRecord ? designRecord["variantId"] : null,
    selectedVariantRecord ? selectedVariantRecord["id"] : null,
    selectedVariant ? (selectedVariant.sku as string) : null,
  );
}

function getCartSelectedVariant(row: CartRow) {
  return row.selected_variant && typeof row.selected_variant === "object" ? row.selected_variant : null;
}

function getSavedSelectedVariant(userProduct: UserProductRow | null) {
  const designRecord =
    userProduct?.design_data && typeof userProduct.design_data === "object"
      ? (userProduct.design_data as Record<string, unknown>)
      : null;
  return designRecord?.selectedVariant && typeof designRecord.selectedVariant === "object"
    ? (designRecord.selectedVariant as Record<string, unknown>)
    : null;
}

function resolveSavedVariantId(userProduct: UserProductRow | null) {
  const designRecord =
    userProduct?.design_data && typeof userProduct.design_data === "object"
      ? (userProduct.design_data as Record<string, unknown>)
      : null;
  const selectedVariant = getSavedSelectedVariant(userProduct);
  return firstString(
    designRecord ? designRecord.variantId : null,
    selectedVariant?.id,
    selectedVariant?.variantId,
  );
}

function resolveProductUid(variant: VariantRow | null, row: CartRow, userProduct: UserProductRow | null, product: ProductRow | null | undefined) {
  const selectedVariant = row.selected_variant && typeof row.selected_variant === "object" ? row.selected_variant : null;
  const designData = userProduct?.design_data && typeof userProduct.design_data === "object" ? userProduct.design_data : null;
  return firstString(
    variant?.gelato_product_uid,
    selectedVariant?.gelato_product_uid,
    selectedVariant?.gelatoProductUid,
    userProduct?.gelato_product_uid,
    designData ? (designData.gelatoProductUid as string) : null,
    designData ? (designData.gelato_product_uid as string) : null,
    product?.gelato_product_uid,
  );
}

function collectFiles(value: unknown): GelatoFile[] {
  if (!value || typeof value !== "object") return [];
  const record = value as Record<string, unknown>;
  const files: GelatoFile[] = [];
  const push = (type: string, url: unknown) => {
    if (typeof url !== "string" || !/^https?:\/\//i.test(url.trim())) return;
    const normalizedType = type.trim().toLowerCase() === "front" ? "default" : type.trim().toLowerCase();
    if (!files.some((entry) => entry.type === normalizedType && entry.url === url.trim())) {
      files.push({ type: normalizedType, url: url.trim() });
    }
  };
  if (Array.isArray(record.files)) {
    for (const entry of record.files) {
      if (!entry || typeof entry !== "object") continue;
      const item = entry as Record<string, unknown>;
      push(String(item.type ?? item.side ?? "default"), item.url ?? item.fileUrl ?? item.printFileUrl ?? item.print_file_url);
    }
  }
  if (record.front) push("front", record.front);
  if (record.back) push("back", record.back);
  if (record.print_files && typeof record.print_files === "object") {
    const pf = record.print_files as Record<string, unknown>;
    push("front", pf.front);
    push("back", pf.back);
  }
  return files;
}

function asUrl(value: unknown): string | null {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (!value || typeof value !== "object") return null;
  const record = value as Record<string, unknown>;
  if (typeof record.url === "string" && record.url.trim()) return record.url.trim();
  if (typeof record.fileUrl === "string" && record.fileUrl.trim()) return record.fileUrl.trim();
  if (typeof record.printFileUrl === "string" && record.printFileUrl.trim()) return record.printFileUrl.trim();
  return null;
}

function buildProductionFiles(printFiles: Record<string, unknown> | null | undefined) {
  const record = printFiles && typeof printFiles === "object" ? printFiles : {};
  const seen = new Set<string>();
  const files: GelatoFile[] = [];
  const push = (type: "default" | "back", value: unknown) => {
    const url = asUrl(value);
    if (!url || url.includes("/mockups/") || seen.has(`${type}:${url}`) || seen.has(url)) return;
    seen.add(`${type}:${url}`);
    seen.add(url);
    files.push({ type, url });
  };

  push("default", record.front);
  push("default", record.default);
  push("default", record.front_url);
  push("back", record.back);
  push("back", record.back_url);

  return files;
}

function uniqueStrings(values: Iterable<string>) {
  return [...new Set([...values].map((value) => value.trim().toLowerCase()).filter(Boolean))];
}

function collectPrintAreasFromUnknown(value: unknown, path: string[] = []): string[] {
  if (!value) return [];
  if (typeof value === "string") {
    const key = path.at(-1)?.toLowerCase() ?? "";
    return /^(type|filetype|file_type|uid|name|id|printarea|print_area|area|placement|location)$/.test(key)
      ? [value]
      : [];
  }
  if (Array.isArray(value)) {
    return value.flatMap((entry, index) => collectPrintAreasFromUnknown(entry, [...path, String(index)]));
  }
  if (typeof value !== "object") return [];

  const record = value as Record<string, unknown>;
  return Object.entries(record).flatMap(([key, entry]) => {
    const keyPath = [...path, key];
    const keyLooksRelevant = /print.?areas?|print.?locations?|file.?types?|placements?/i.test(key);
    if (keyLooksRelevant) return collectPrintAreasFromUnknown(entry, keyPath);
    return collectPrintAreasFromUnknown(entry, keyPath).filter((area) => area === "default" || area === "back");
  });
}

function extractProductPrintAreas(product: GelatoProductDetails | GelatoCatalogSearchProduct | null | undefined) {
  if (!product) return [];
  const direct = uniqueStrings(collectPrintAreasFromUnknown(product));
  const supported = direct.filter((area) => area === "default" || area === "back");
  return supported.length ? supported : ["default"];
}

function extractGelatoCatalogUid(product: GelatoProductDetails | null | undefined) {
  if (!product) return null;
  const record = product as Record<string, unknown>;
  const catalog = record.catalog && typeof record.catalog === "object" ? (record.catalog as Record<string, unknown>) : null;
  return (
    firstString(
      record.catalogUid,
      record.catalog_uid,
      catalog?.catalogUid,
      catalog?.uid,
      catalog?.id,
    ) || null
  );
}

async function readGelatoSyncStates(productIds: string[]) {
  if (!productIds.length) return { data: [] as GelatoSyncStateRow[], error: null };
  const client = process.env.SUPABASE_SERVICE_ROLE_KEY ? createSupabaseAdmin() : createSupabaseServer();
  return client
    .from("gelato_catalog_sync_state")
    .select("product_id, catalog_uid")
    .in("product_id", productIds);
}

function supportsRequiredPrintAreas(available: string[], required: string[]) {
  const availableSet = new Set(available);
  return required.every((area) => availableSet.has(area));
}

function isPrintConfigurationAttribute(attributeUid: string) {
  return /print|area|placement|location|side|position|application/i.test(attributeUid);
}

function buildEquivalentProductFilters(attributes: Record<string, string>) {
  return Object.fromEntries(
    Object.entries(attributes)
      .filter(([key, value]) => value.trim() && !isPrintConfigurationAttribute(key))
      .map(([key, value]) => [key, [value.trim()]]),
  );
}

async function resolveProductUidForPrintAreas(input: {
  currentProductUid: string;
  productId: string;
  catalogUid: string | null;
  requiredPrintAreas: string[];
}): Promise<GelatoPrintAreaResolution> {
  const currentDetails = await getGelatoProduct(input.currentProductUid);
  const currentPrintAreas = extractProductPrintAreas(currentDetails);
  if (supportsRequiredPrintAreas(currentPrintAreas, input.requiredPrintAreas)) {
    return {
      productUid: input.currentProductUid,
      currentPrintAreas,
      resolvedPrintAreas: currentPrintAreas,
      catalogUid: input.catalogUid,
      catalogUidSource: "not_needed",
      resolvedFrom: "current",
    };
  }

  const catalogUid = input.catalogUid ?? extractGelatoCatalogUid(currentDetails);
  if (!catalogUid) {
    throw new Error("Missing Gelato catalog UID for back-print product resolution.");
  }

  const filters = buildEquivalentProductFilters(currentDetails.attributes ?? {});
  const searchResult = await searchGelatoCatalogProducts(catalogUid, filters, 100, 0);
  const candidates = Array.isArray(searchResult.products) ? searchResult.products : [];

  for (const candidate of candidates) {
    if (candidate.productUid === input.currentProductUid) continue;
    const candidateDetails = await getGelatoProduct(candidate.productUid);
    const candidatePrintAreas = extractProductPrintAreas(candidateDetails);
    if (supportsRequiredPrintAreas(candidatePrintAreas, input.requiredPrintAreas)) {
      return {
        productUid: candidate.productUid,
        currentPrintAreas,
        resolvedPrintAreas: candidatePrintAreas,
        catalogUid,
        catalogUidSource: input.catalogUid ? "gelato_catalog_sync_state" : "product_api",
        resolvedFrom: "catalog_search",
      };
    }
  }

  throw new Error("Unable to resolve a Gelato product UID that supports front and back print areas.");
}

function determineRequiredSides(userProduct: UserProductRow | null) {
  const designData = userProduct?.design_data && typeof userProduct.design_data === "object" ? (userProduct.design_data as Record<string, unknown>) : null;
  const frontElements = designData?.sides && typeof designData.sides === "object"
    ? (designData.sides as Record<string, unknown>).front && typeof (designData.sides as Record<string, unknown>).front === "object"
      ? ((designData.sides as Record<string, unknown>).front as Record<string, unknown>).elements
      : null
    : null;
  const backElements = designData?.sides && typeof designData.sides === "object"
    ? (designData.sides as Record<string, unknown>).back && typeof (designData.sides as Record<string, unknown>).back === "object"
      ? ((designData.sides as Record<string, unknown>).back as Record<string, unknown>).elements
      : null
    : null;
  const frontHasDesign = Array.isArray(frontElements) && frontElements.length > 0;
  const backHasDesign = Array.isArray(backElements) && backElements.length > 0;
  return { frontHasDesign, backHasDesign };
}

function log(event: string, data?: Record<string, unknown>) {
  console.info(event, data ?? {});
}

function gelatoRequestPayload(input: {
  idempotencyKey: string;
  currency: string;
  shippingMethod: {
    id: string;
    code?: string | null;
    shipmentMethodUid: string;
    name: string;
    price: number;
    currency: string;
  };
  address: ReturnType<typeof normalizeAddress>;
  items: Array<{ cartItemId: string; userProductId: string | null; productUid: string; quantity: number; files: GelatoFile[] }>;
  email: string;
}) {
  return {
    orderType: "draft" as const,
    orderReferenceId: input.idempotencyKey,
    customerReferenceId: input.email,
    currency: input.currency,
    shipmentMethodUid: input.shippingMethod.shipmentMethodUid,
    shippingAddress: {
      firstName: input.address.firstName,
      lastName: input.address.lastName,
      addressLine1: input.address.addressLine1,
      addressLine2: input.address.addressLine2,
      city: input.address.city,
      state: input.address.state,
      postCode: input.address.postalCode,
      country: input.address.countryCode,
      email: input.address.email,
      phone: input.address.phone ?? "",
    },
    items: input.items.map((item) => ({
      itemReferenceId: item.cartItemId,
      productUid: item.productUid,
      quantity: item.quantity,
      files: item.files,
      metadata: [
        { key: "cartItemId", value: item.cartItemId },
        { key: "userProductId", value: item.userProductId ?? "" },
      ].filter((entry) => entry.value),
    })),
    metadata: [
      { key: "source", value: "ryfio_checkout" },
      { key: "shippingMethodId", value: input.shippingMethod.id },
      { key: "shippingMethodCode", value: input.shippingMethod.code ?? "" },
    ].filter((entry) => entry.value),
  };
}

export async function POST(req: Request) {
  try {
    const supabase = createSupabaseServer();
    const body = (await req.json().catch(() => null)) as DraftBody | null;
    const cartItemIds = Array.from(new Set((body?.cartItemIds ?? []).filter(isUuid)));
    const shippingMethodInput = body?.shippingMethod ?? null;
    const address = normalizeAddress(body ?? {});

    console.info("[checkout:draft:01-request]", {
      cartItemCount: Array.isArray(body?.cartItemIds) ? body.cartItemIds.length : 0,
      hasAddress: Boolean(body?.address),
      hasShippingMethod: Boolean(body?.shippingMethod),
      selectedShippingMethod: body?.shippingMethod
        ? {
            id: body.shippingMethod.id ?? null,
            code: body.shippingMethod.code ?? null,
            shipmentMethodUid: body.shippingMethod.shipmentMethodUid ?? null,
            name: body.shippingMethod.name ?? null,
            price: body.shippingMethod.price ?? null,
            currency: body.shippingMethod.currency ?? null,
          }
        : null,
    });

    const { data: authData, error: authError } = await supabase.auth.getUser();
    if (authError) {
      console.error("[checkout:draft:02-auth-failed]", { message: authError.message ?? "Unknown auth error" });
    }
    console.info("[checkout:draft:02-auth]", {
      authenticated: Boolean(authData.user?.id),
      userIdSuffix: authData.user?.id ? authData.user.id.slice(-8) : null,
    });
    if (!authData.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    if (!cartItemIds.length) return NextResponse.json({ code: "MISSING_CART_ITEMS", success: false }, { status: 400 });
    if (
      !shippingMethodInput?.id ||
      !shippingMethodInput.shipmentMethodUid ||
      !shippingMethodInput.name ||
      shippingMethodInput.currency?.toUpperCase() !== "EUR"
    ) {
      return NextResponse.json({ code: "MISSING_SHIPPING_METHOD", success: false }, { status: 400 });
    }
    if (!address.firstName || !address.lastName || !address.email || !address.addressLine1 || !address.city || !address.postalCode || !address.countryCode) {
      return NextResponse.json({ code: "ADDRESS_INVALID", success: false }, { status: 400 });
    }

    const { data: cartRows, error: cartError } = await supabase
      .from("cart_items")
      .select("id, user_id, product_id, variant_id, user_product_id, design_id, quantity, selected_variant, title")
      .eq("user_id", authData.user.id)
      .in("id", cartItemIds);
    if (cartError) return NextResponse.json({ error: cartError.message }, { status: 500 });
    if ((cartRows ?? []).length !== cartItemIds.length) return NextResponse.json({ error: "CART_OWNERSHIP_INVALID" }, { status: 403 });

    console.info("[checkout:draft:03-cart-items]", {
      requestedCount: cartItemIds.length,
      loadedCount: cartRows?.length ?? 0,
      items: (cartRows ?? []).map((item) => ({
        cartItemId: item.id,
        productId: item.product_id ?? null,
        userProductId: item.user_product_id ?? null,
        variantId: item.variant_id ?? null,
        sku: null,
        size: null,
        quantity: item.quantity ?? null,
        hasSelectedVariant: Boolean(item.selected_variant),
      })),
    });

    const userProductIds = Array.from(
      new Set(
        (cartRows ?? [])
          .map((item) => item.user_product_id)
          .filter((id): id is string => typeof id === "string" && id.length > 0),
      ),
    );
    const designIds = Array.from(new Set((cartRows ?? []).map((row) => row.design_id).filter((value): value is string => Boolean(value))));
    const productIds = Array.from(new Set((cartRows ?? []).map((row) => row.product_id)));
    const variantHints = Array.from(new Set((cartRows ?? []).map((row) => row.variant_id).filter((value): value is string => Boolean(value))));

    const productRowsPromise = supabase.from("products").select("id, gelato_product_uid, price").in("id", productIds);
    const variantRowsPromise = supabase.from("product_variants").select("id, sku, size, product_color_id, gelato_product_uid, price, name").in("id", variantHints);
    const syncStateRowsPromise = readGelatoSyncStates(productIds);
    const userProductRowsPromise = userProductIds.length
      ? supabase
          .from("user_products")
          .select("id, user_id, price, markup, final_price, design_data, print_files, mockups")
          .eq("user_id", authData.user.id)
          .in("id", userProductIds)
      : Promise.resolve({ data: [] as UserProductRow[], error: null });

    const [{ data: productRows }, { data: variantRows }, syncStateResult, userProductResult] = await Promise.all([
      productRowsPromise,
      variantRowsPromise,
      syncStateRowsPromise,
      userProductRowsPromise,
    ]);
    const syncStateRows = "data" in syncStateResult ? syncStateResult.data : [];
    const syncStateRowsError = "error" in syncStateResult ? syncStateResult.error : null;
    const userProductRows = "data" in userProductResult ? userProductResult.data : [];
    const userProductRowsError = "error" in userProductResult ? userProductResult.error : null;

    if (syncStateRowsError) {
      console.error("[checkout:draft:sync-state-query-failed]", {
        message: syncStateRowsError.message,
        code: syncStateRowsError.code,
        productIds,
      });
    }

    if (userProductRowsError) {
      console.error("[checkout:draft:user-products-query-failed]", {
        message: userProductRowsError.message,
        code: userProductRowsError.code,
        requestedCount: userProductIds.length,
      });
      return NextResponse.json(
        {
          success: false,
          code: "USER_PRODUCTS_QUERY_FAILED",
          message: "Unable to load user products for checkout draft.",
        },
        { status: 500 },
      );
    }

    const userProductById = new Map((userProductRows ?? []).map((row) => [(row as UserProductRow).id, row as UserProductRow]));
    let allVariantRows = (variantRows ?? []) as VariantRow[];
    const fallbackVariantIds = Array.from(
      new Set(
        (cartRows ?? [])
          .flatMap((row) => {
            const userProductId = row.user_product_id;
            const userProduct =
              typeof userProductId === "string"
                ? userProductById.get(userProductId) ?? null
                : null;
            const legacyDesignUserProduct = !userProduct && row.design_id ? userProductById.get(row.design_id) ?? null : null;
            const resolvedUserProduct = userProduct ?? legacyDesignUserProduct;
            const cartSelectedVariant = getCartSelectedVariant(row as CartRow);
            return [
              firstString(cartSelectedVariant?.id, cartSelectedVariant?.variantId),
              resolveSavedVariantId(resolvedUserProduct),
            ];
          })
          .filter((value): value is string => Boolean(value) && !allVariantRows.some((variant) => variant.id === value)),
      ),
    );

    if (fallbackVariantIds.length) {
      const { data: fallbackVariantRows, error: fallbackVariantRowsError } = await supabase
        .from("product_variants")
        .select("id, sku, size, product_color_id, gelato_product_uid, price, name")
        .in("id", fallbackVariantIds);
      if (fallbackVariantRowsError) {
        console.error("[checkout:draft:fallback-variants-query-failed]", {
          message: fallbackVariantRowsError.message,
          code: fallbackVariantRowsError.code,
          fallbackVariantIds,
        });
      } else {
        allVariantRows = [...allVariantRows, ...((fallbackVariantRows ?? []) as VariantRow[])];
      }
    }

    const productMap = new Map((productRows ?? []).map((row) => [(row as ProductRow).id, row as ProductRow]));
    const variantMap = new Map(allVariantRows.map((row) => [row.id, row]));
    const syncStateMap = new Map((syncStateRows ?? []).map((row) => [(row as GelatoSyncStateRow).product_id, row as GelatoSyncStateRow]));

    const resolvedItems: Array<{ cartItemId: string; userProductId: string | null; productUid: string; quantity: number; files: GelatoFile[]; unitPrice: number }> = [];
    let subtotal = 0;
    const quoteCurrency = "EUR";

    for (const cartRow of cartRows ?? []) {
      const userProductId = cartRow.user_product_id;
      const userProduct =
        typeof userProductId === "string"
          ? userProductById.get(userProductId) ?? null
          : null;
      const legacyDesignUserProduct = !userProduct && cartRow.design_id ? userProductById.get(cartRow.design_id) ?? null : null;
      const resolvedUserProduct = userProduct ?? legacyDesignUserProduct;
      console.info("[checkout:draft:user-product-resolution]", {
        cartItemId: cartRow.id,
        requestedUserProductId: cartRow.user_product_id ?? null,
        found: Boolean(resolvedUserProduct),
        resolvedUserProductId: resolvedUserProduct?.id ?? null,
        loadedUserProductsCount: userProductRows?.length ?? 0,
        loadedUserProductIds: (userProductRows ?? []).map((item) => item.id),
      });
      const cartSelectedVariant = getCartSelectedVariant(cartRow as CartRow);
      const savedSelectedVariant = getSavedSelectedVariant(resolvedUserProduct);
      const savedSelectedVariantId = resolveSavedVariantId(resolvedUserProduct);
      const cartSelectedVariantId = firstString(cartSelectedVariant?.id, cartSelectedVariant?.variantId);
      const cartVariant = cartRow.variant_id ? variantMap.get(cartRow.variant_id) ?? null : null;
      const cartSelectedVariantRow = cartSelectedVariantId ? variantMap.get(cartSelectedVariantId) ?? null : null;
      const savedSelectedVariantRow = savedSelectedVariantId ? variantMap.get(savedSelectedVariantId) ?? null : null;
      const variant = cartVariant ?? cartSelectedVariantRow ?? savedSelectedVariantRow ?? null;
      const resolutionSource = cartVariant
        ? "cart_items.variant_id"
        : cartSelectedVariantRow
          ? "cart_items.selected_variant"
          : savedSelectedVariantRow
            ? "user_products.design_data.selectedVariant"
            : "missing";

      console.info("[checkout:draft:variant-resolution]", {
        cartItemId: cartRow.id,
        cartVariantId: cartRow.variant_id ?? null,
        cartVariantSku: cartVariant?.sku ?? null,
        savedSelectedVariantId,
        savedSelectedVariantSku: savedSelectedVariantRow?.sku ?? firstString(savedSelectedVariant?.sku),
        resolvedVariantId: variant?.id ?? null,
        resolvedVariantSku: variant?.sku ?? null,
        resolutionSource,
      });

      if (!variant) {
        console.error("[checkout:draft:04-variant-failed]", {
          cartItemId: cartRow.id,
          productId: cartRow.product_id ?? null,
          variantId: cartRow.variant_id ?? null,
          cartSelectedVariantId,
          savedSelectedVariantId,
          sku: cartSelectedVariant?.sku ?? null,
          size: cartSelectedVariant?.size ?? null,
          selectedVariantKeys:
            cartRow.selected_variant && typeof cartRow.selected_variant === "object" ? Object.keys(cartRow.selected_variant) : [],
        });
        return conflict("MISSING_VARIANT", "Unable to resolve a variant for this cart item.", { cartItemId: cartRow.id });
      }

      const product = productMap.get(cartRow.product_id) ?? null;
      const currentProductUid = resolveProductUid(variant, cartRow as CartRow, userProduct, product);
      let productUid = currentProductUid;
      if (!productUid) {
        return conflict("MISSING_PRODUCT_UID", "Unable to resolve the Gelato product UID for this cart item.", { cartItemId: cartRow.id });
      }

      const userDesignData = userProduct?.design_data && typeof userProduct.design_data === "object"
        ? (userProduct.design_data as Record<string, unknown>)
        : null;
      const userSelectedVariant = userDesignData?.selectedVariant && typeof userDesignData.selectedVariant === "object"
        ? (userDesignData.selectedVariant as Record<string, unknown>)
        : null;

      console.info("[checkout:draft:04-variant-resolution]", {
        cartItemId: cartRow.id,
        originalVariantId: cartRow.variant_id ?? null,
        selectedVariantId: cartRow.selected_variant && typeof cartRow.selected_variant === "object" ? (cartRow.selected_variant as Record<string, unknown>).id ?? null : null,
        userProductVariantId: userDesignData?.variantId ?? userSelectedVariant?.id ?? null,
        resolvedVariantId: variant?.id ?? null,
        resolutionSource,
        sku: variant?.sku ?? cartRow.selected_variant?.sku ?? null,
        size: variant?.size ?? cartRow.selected_variant?.size ?? null,
        gelatoProductUidPresent: Boolean(productUid),
        gelatoProductUidPrefix: typeof productUid === "string" ? productUid.slice(0, 45) : null,
      });

      const designData = resolvedUserProduct?.design_data && typeof resolvedUserProduct.design_data === "object"
        ? (resolvedUserProduct.design_data as Record<string, unknown>)
        : null;
      const frontElements = designData?.sides && typeof designData.sides === "object" && (designData.sides as Record<string, unknown>).front && typeof (designData.sides as Record<string, unknown>).front === "object"
        ? ((designData.sides as Record<string, unknown>).front as Record<string, unknown>).elements
        : null;
      const backElements = designData?.sides && typeof designData.sides === "object" && (designData.sides as Record<string, unknown>).back && typeof (designData.sides as Record<string, unknown>).back === "object"
        ? ((designData.sides as Record<string, unknown>).back as Record<string, unknown>).elements
        : null;
      const frontHasDesign = Array.isArray(frontElements) && frontElements.length > 0;
      const backHasDesign = Array.isArray(backElements) && backElements.length > 0;
      const printFilesRecord = resolvedUserProduct?.print_files && typeof resolvedUserProduct.print_files === "object"
        ? (resolvedUserProduct.print_files as Record<string, unknown>)
        : {};
      const mockupsRecord = resolvedUserProduct?.mockups && typeof resolvedUserProduct.mockups === "object"
        ? (resolvedUserProduct.mockups as Record<string, unknown>)
        : {};
      const printFilesFinal = buildProductionFiles(printFilesRecord);
      const frontPrintFile = printFilesFinal.find((file) => file.type === "default")?.url ?? null;
      const backPrintFile = printFilesFinal.find((file) => file.type === "back")?.url ?? null;
      const hasBack = backHasDesign && Boolean(backPrintFile);
      const requiredPrintAreas = hasBack ? ["default", "back"] : ["default"];
      const syncState = syncStateMap.get(cartRow.product_id) ?? null;
      const catalogUid = syncState?.catalog_uid ?? null;
      const catalogUidSource = catalogUid ? "gelato_catalog_sync_state" : "missing";
      const familyKey = null;

      let printAreaResolution: GelatoPrintAreaResolution = {
        productUid,
        currentPrintAreas: ["default"],
        resolvedPrintAreas: ["default"],
        catalogUid,
        catalogUidSource,
        resolvedFrom: "current",
      };
      if (hasBack) {
        try {
          printAreaResolution = await resolveProductUidForPrintAreas({
            currentProductUid: productUid,
            productId: cartRow.product_id,
            catalogUid,
            requiredPrintAreas,
          });
          productUid = printAreaResolution.productUid;
        } catch (error) {
          console.error("[checkout:draft:print-area-resolution-failed]", {
            cartItemId: cartRow.id,
            currentProductUid,
            hasFront: Boolean(frontPrintFile),
            hasBack,
            requiredPrintAreas,
            productId: cartRow.product_id,
            syncStateFound: Boolean(syncState),
            syncStateId: syncState?.product_id ?? null,
            familyKey,
            catalogUid,
            catalogUidSource,
            message: error instanceof Error ? error.message : "Unknown Gelato print area resolution error.",
          });
          return conflict("GELATO_PRINT_AREAS_UNSUPPORTED", "Unable to resolve a Gelato product UID that supports front and back print areas.", {
            cartItemId: cartRow.id,
            currentProductUid,
            requiredPrintAreas,
          });
        }
      }

      console.info("[checkout:draft:print-area-resolution]", {
        cartItemId: cartRow.id,
        currentProductUid,
        productId: cartRow.product_id,
        syncStateFound: Boolean(syncState),
        syncStateId: syncState?.product_id ?? null,
        familyKey,
        catalogUid: printAreaResolution.catalogUid,
        catalogUidSource: printAreaResolution.catalogUidSource,
        hasFront: Boolean(frontPrintFile),
        hasBack,
        requiredPrintAreas,
        currentPrintAreas: printAreaResolution.currentPrintAreas,
        resolvedProductUid: productUid,
        resolvedPrintAreas: printAreaResolution.resolvedPrintAreas,
        resolvedFrom: printAreaResolution.resolvedFrom,
        filesSent: printFilesFinal.map((file) => file.type),
      });
      console.info("[checkout:draft:production-files]", {
        cartItemId: cartRow.id,
        printFilesFound: {
          front: asUrl(printFilesRecord.front) ?? asUrl(printFilesRecord.default) ?? asUrl(printFilesRecord.front_url) ?? null,
          back: asUrl(printFilesRecord.back) ?? asUrl(printFilesRecord.back_url) ?? null,
        },
        mockupsFound: {
          front: asUrl(mockupsRecord.front) ?? asUrl(mockupsRecord.front_url) ?? null,
          back: asUrl(mockupsRecord.back) ?? asUrl(mockupsRecord.back_url) ?? null,
        },
        filesSentToGelato: [
          ...printFilesFinal,
        ],
      });
      console.info("[checkout:draft:05-print-files]", {
        cartItemId: cartRow.id,
        userProductId: resolvedUserProduct?.id ?? null,
        frontHasDesign,
        backHasDesign,
        printFilesKeys: Object.keys(printFilesRecord),
        frontExists: Boolean(frontPrintFile),
        backExists: Boolean(backPrintFile),
        frontProtocol: typeof frontPrintFile === "string" ? frontPrintFile.split(":")[0] : null,
        backProtocol: typeof backPrintFile === "string" ? backPrintFile.split(":")[0] : null,
      });

      if (frontHasDesign && !frontPrintFile) {
        return conflict("PRINT_FILES_NOT_READY", "Print files are not ready for this cart item.", {
          userProductId: resolvedUserProduct?.id ?? cartRow.user_product_id ?? null,
          missingSides: ["front"],
        });
      }
      if (backHasDesign && !backPrintFile) {
        return conflict("PRINT_FILES_NOT_READY", "Print files are not ready for this cart item.", {
          userProductId: resolvedUserProduct?.id ?? cartRow.user_product_id ?? null,
          missingSides: ["back"],
        });
      }
      if (!frontPrintFile && !backPrintFile) {
        return conflict("PRINT_FILES_NOT_READY", "Print files are not ready for this cart item.", {
          userProductId: resolvedUserProduct?.id ?? cartRow.user_product_id ?? null,
          missingSides: frontHasDesign ? ["front"] : [],
        });
      }

      const quantity = Math.max(1, Number(cartRow.quantity) || 1);
      const containsMockupPath = printFilesFinal.some((file) => file.url.includes("/mockups/"));
      if (containsMockupPath) {
        return conflict("PRINT_FILES_NOT_READY", "Print files are not ready for this cart item.", {
          userProductId: resolvedUserProduct?.id ?? cartRow.user_product_id ?? null,
          missingSides: [],
        });
      }
      // Keep the draft financial snapshot aligned with the final Stripe checkout:
      // current server-side variant price + the trusted €6 second-print charge
      // persisted by Save Design. Never use a price supplied by the browser.
      const currentVariantBasePrice = Number(variant?.price ?? resolvedUserProduct?.price ?? product?.price ?? 0);
      const storedMarkup = Number(resolvedUserProduct?.markup ?? 0);
      const trustedSecondPrintCharge = resolvedUserProduct && storedMarkup === 6 ? 6 : 0;
      const unitPrice = currentVariantBasePrice + trustedSecondPrintCharge;

      if (!Number.isFinite(unitPrice) || unitPrice <= 0) {
        return conflict("INVALID_OFFICIAL_PRICE", "Unable to resolve an official EUR price for this cart item.", {
          cartItemId: cartRow.id,
          variantId: variant?.id ?? null,
        });
      }

      console.info("[checkout:draft:price-resolution]", {
        cartItemId: cartRow.id,
        variantId: variant?.id ?? null,
        variantBasePrice: currentVariantBasePrice,
        userProductId: resolvedUserProduct?.id ?? null,
        storedFinalPrice: resolvedUserProduct?.final_price ?? null,
        trustedSecondPrintCharge,
        unitPrice,
        quantity,
        lineTotal: unitPrice * quantity,
        currency: "EUR",
        policy: "current_variant_plus_server_second_print",
      });

      resolvedItems.push({ cartItemId: cartRow.id, userProductId: resolvedUserProduct?.id ?? cartRow.user_product_id ?? null, productUid, quantity, files: printFilesFinal, unitPrice });
      subtotal += unitPrice * quantity;
    }

    const quoteItems = resolvedItems.map((item) => ({
      itemReferenceId: item.cartItemId,
      productUid: item.productUid,
      quantity: item.quantity,
      printFiles: item.files,
    }));

    console.info("[checkout:draft:06-quote-items]", {
      count: quoteItems.length,
      items: quoteItems.map((item) => ({
        itemReferenceId: item.itemReferenceId ?? null,
        productUidPresent: Boolean(item.productUid),
        productUidPrefix: typeof item.productUid === "string" ? item.productUid.slice(0, 50) : null,
        quantity: item.quantity,
        printFilesCount: Array.isArray(item.printFiles) ? item.printFiles.length : 0,
        printFileTypes: Array.isArray(item.printFiles) ? item.printFiles.map((file) => file.type) : [],
        printFileProtocols: Array.isArray(item.printFiles)
          ? item.printFiles.map((file) => (typeof file.url === "string" ? file.url.split(":")[0] : null))
          : [],
      })),
    });

    console.info("[checkout:draft:07-address]", {
      countryCode: address.countryCode ?? null,
      postalCodeLength: address.postalCode?.length ?? 0,
      cityPresent: Boolean(address.city),
      addressLine1Present: Boolean(address.addressLine1),
      statePresent: Boolean(address.state),
      stateCodePresent: Boolean(address.stateCode),
      emailPresent: Boolean(address.email),
      phonePresent: Boolean(address.phone),
    });

    const quotePayload = buildGelatoCheckoutQuotePayload({
      productUid: quoteItems[0].productUid,
      quantity: quoteItems[0].quantity,
      shippingAddress: {
        ...address,
        countryCode: address.countryCode,
      },
      printFiles: quoteItems[0].printFiles,
      items: quoteItems,
      currencyIsoCode: quoteCurrency,
    });

    const safeQuotePayload = {
      ...quotePayload,
      shippingAddress: quotePayload.recipient
        ? {
            country: quotePayload.recipient.countryIsoCode ?? null,
            postCodePresent: Boolean(quotePayload.recipient.postcode),
            cityPresent: Boolean(quotePayload.recipient.city),
            addressLine1Present: Boolean(quotePayload.recipient.addressLine1),
          }
        : null,
      products: Array.isArray(quotePayload.products)
        ? quotePayload.products.map((item) => ({
            itemReferenceId: item.itemReferenceId ?? null,
            productUid: item.productUid ?? null,
            quantity: item.quantity ?? null,
            pdfUrlPresent: Boolean(item.pdfUrl),
          }))
        : [],
    };

    console.info("[checkout:draft:08-gelato-quote-payload]", JSON.stringify(safeQuotePayload, null, 2));

    // IMPORTANT: Do not request a second Gelato quote here. Gelato shipmentMethodUid
    // values are quote-scoped and can change between otherwise identical quotes.
    // The UID selected from /api/checkout/availability must be forwarded unchanged
    // to the Draft Order request.
    const matched = {
      id: shippingMethodInput.id,
      code: shippingMethodInput.code ?? null,
      shipmentMethodUid: shippingMethodInput.shipmentMethodUid,
      name: shippingMethodInput.name,
      price: Number(shippingMethodInput.price),
      currency: "EUR",
    };

    log("[checkout:draft-quote]", {
      available: true,
      retryable: false,
      reason: "reused_selected_shipping_method",
      shippingMethodsCount: 1,
    });

    console.info("[checkout:draft:09-gelato-http]", {
      status: null,
      ok: null,
      contentType: null,
      bodyLength: null,
    });

    console.info("[checkout:draft:11-shipping-method]", {
      id: matched.id,
      code: matched.code ?? null,
      shipmentMethodUid: matched.shipmentMethodUid,
      name: matched.name,
      price: matched.price,
      currency: matched.currency,
    });

    console.info("[checkout:draft:12-shipping-match]", {
      selectedId: shippingMethodInput.id ?? null,
      selectedCode: shippingMethodInput.code ?? null,
      selectedShipmentMethodUid: shippingMethodInput.shipmentMethodUid ?? null,
      availableCount: 1,
      matched: true,
      matchedId: matched.id,
      matchedCode: matched.code ?? null,
      matchedShipmentMethodUid: matched.shipmentMethodUid,
    });

    const idempotencyKey = hashIdempotencyKey({
      userId: authData.user.id,
      cartItemIds: [...cartItemIds].sort(),
      postalCode: address.postalCode,
      countryCode: address.countryCode,
      shippingMethodId: shippingMethodInput.shipmentMethodUid,
    });

    const { data: existingDraft } = await supabase
      .from("checkout_drafts")
      .select("id, gelato_draft_order_id, shipping_method, subtotal, shipping_amount, total, currency")
      .eq("idempotency_key", idempotencyKey)
      .maybeSingle();

    if (existingDraft?.gelato_draft_order_id) {
      return NextResponse.json({
        success: true,
        draftOrderId: existingDraft.id,
        gelatoDraftOrderId: existingDraft.gelato_draft_order_id,
        shippingMethod: shippingMethodInput,
        subtotal: existingDraft.subtotal ?? 0,
        shipping: existingDraft.shipping_amount ?? matched.price,
        total: existingDraft.total ?? matched.price,
        currency: existingDraft.currency ?? matched.currency,
      });
    }

    const gelatoPayload = gelatoRequestPayload({
      idempotencyKey,
      currency: "EUR",
      shippingMethod: matched,
      address,
      items: resolvedItems,
      email: authData.user.email ?? authData.user.id,
    });

    console.info("[checkout:draft:13-create-start]", {
      itemCount: gelatoPayload.items.length,
      shipmentMethodUidPresent: Boolean(gelatoPayload.shipmentMethodUid),
      shipmentMethodUid: gelatoPayload.shipmentMethodUid,
      currency: gelatoPayload.currency,
    });

    log("[checkout:variant-resolution]", { itemCount: resolvedItems.length });
    log("[checkout:shipping-validation]", { shippingMethodId: matched.id, shippingMethodCode: matched.code ?? null });

    const gelatoApiKey = process.env.GELATO_API_KEY?.trim();
    if (!gelatoApiKey) return NextResponse.json({ success: false, code: "GELATO_DRAFT_FAILED" }, { status: 500 });

    const gelatoResponse = await fetch(new URL("/v4/orders", process.env.GELATO_API_BASE_URL?.trim() || "https://order.gelatoapis.com"), {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-API-KEY": gelatoApiKey },
      body: JSON.stringify(gelatoPayload),
      cache: "no-store",
    });

    const gelatoStatus = gelatoResponse.status;
    const gelatoContentType = gelatoResponse.headers.get("content-type");
    const gelatoRawText = await gelatoResponse.text();
    console.info("[checkout:draft:15-body-read-start]");
    console.info("[checkout:draft:15-body-read-finished]", {
      bodyLength: gelatoRawText.length,
      preview: process.env.NODE_ENV !== "production" ? gelatoRawText.slice(0, 500) : undefined,
    });
    let gelatoBody: unknown = null;
    console.info("[checkout:draft:16-json-parse-start]");
    try {
      gelatoBody = gelatoRawText ? JSON.parse(gelatoRawText) : null;
    } catch (error) {
      console.error("[checkout:draft:16-json-parse-error]", error);
      return NextResponse.json(
        {
          success: false,
          code: "GELATO_DRAFT_INVALID_RESPONSE",
          message: "Gelato returned an invalid Draft Order response.",
        },
        { status: 502 },
      );
    }
    console.info("[checkout:draft:16-json-parse-success]", {
      keys:
        gelatoBody && typeof gelatoBody === "object" && !Array.isArray(gelatoBody)
          ? Object.keys(gelatoBody as Record<string, unknown>)
          : [],
    });
    console.info("[checkout:draft:16-response-shape]", {
      bodyType: Array.isArray(gelatoBody) ? "array" : gelatoBody === null ? "null" : typeof gelatoBody,
      topLevelKeys:
        gelatoBody && typeof gelatoBody === "object" && !Array.isArray(gelatoBody)
          ? Object.keys(gelatoBody as Record<string, unknown>)
          : [],
      arrayLength: Array.isArray(gelatoBody) ? gelatoBody.length : null,
      firstItemKeys:
        Array.isArray(gelatoBody) && gelatoBody[0] && typeof gelatoBody[0] === "object"
          ? Object.keys(gelatoBody[0] as Record<string, unknown>)
          : [],
    });
    const gelatoError = gelatoBody && typeof gelatoBody === "object" ? (gelatoBody as Record<string, unknown>) : null;
    if (!gelatoResponse.ok) {
      console.error("[checkout:draft:10-gelato-error]", {
        httpStatus: gelatoStatus,
        code: gelatoError?.code ?? null,
        message: gelatoError?.message ?? null,
        requestId: gelatoError?.requestId ?? null,
        details: gelatoError?.details ?? null,
        responseKeys: gelatoError ? Object.keys(gelatoError) : [],
      });
      return NextResponse.json(
        {
          success: false,
          code: "GELATO_QUOTE_FAILED",
          message: typeof gelatoError?.message === "string" ? gelatoError.message : "Gelato quote failed.",
          gelatoCode: gelatoError?.code ?? null,
          gelatoRequestId: gelatoError?.requestId ?? null,
          gelatoDetails: gelatoError?.details ?? null,
        },
        { status: 502 },
      );
    }

    function extractGelatoOrderId(body: unknown): string | null {
      const candidates: unknown[] = [];

      const collect = (value: unknown) => {
        if (!value || typeof value !== "object") return;

        const row = value as Record<string, unknown>;
        candidates.push(row.id, row.orderId, row.order_id, row.draftOrderId, row.orderReferenceId);

        if (row.order && typeof row.order === "object") {
          const order = row.order as Record<string, unknown>;
          candidates.push(order.id, order.orderId, order.order_id, order.orderReferenceId);
        }

        if (row.data && typeof row.data === "object") {
          const data = row.data as Record<string, unknown>;
          candidates.push(data.id, data.orderId, data.order_id, data.draftOrderId, data.orderReferenceId);
        }

        if (row.orders && Array.isArray(row.orders)) {
          for (const order of row.orders) collect(order);
        }
      };

      if (Array.isArray(body)) {
        for (const item of body) collect(item);
      } else {
        collect(body);
      }

      const found = candidates.find((value) => typeof value === "string" && value.trim().length > 0);
      return typeof found === "string" ? found.trim() : null;
    }

    console.info("[checkout:draft:17-id-resolution-start]");
    const gelatoDraftOrderId = extractGelatoOrderId(gelatoBody);
    const gelatoOrderReferenceId = (gelatoResponse as any)?.orderReferenceId ?? (gelatoBody as any)?.orderReferenceId ?? null;
    console.info("[checkout:draft:17-id-resolution]", {
      gelatoDraftOrderId,
      orderId: (gelatoBody as Record<string, unknown> | null)?.id ?? null,
      externalId: (gelatoBody as Record<string, unknown> | null)?.orderId ?? null,
      reference: (gelatoBody as Record<string, unknown> | null)?.orderReferenceId ?? null,
      gelatoDraftOrderIdPresent: Boolean(gelatoDraftOrderId),
    });
    if (!gelatoDraftOrderId) {
      console.error("[checkout:draft:17-id-missing]", gelatoBody);
      return NextResponse.json(
        {
          success: false,
          code: "GELATO_DRAFT_ID_MISSING",
          message: "Gelato created the draft but did not return a recognized order ID.",
        },
        { status: 502 },
      );
    }
    const draftRow = {
      user_id: authData.user.id,
      cart_item_ids: cartItemIds,
      idempotency_key: idempotencyKey,
      status: "draft",
      gelato_draft_order_id: gelatoDraftOrderId,
      order_reference_id: gelatoOrderReferenceId ?? idempotencyKey,
      selected_shipping_method: {
        id: matched.id,
        code: matched.code,
        shipmentMethodUid: matched.shipmentMethodUid,
        name: matched.name,
        price: matched.price,
        currency: matched.currency,
      },
      shipping_address: address,
      subtotal,
      shipping_amount: matched.price,
      total: subtotal + matched.price,
      currency: matched.currency,
      gelato_response: {
        id: gelatoDraftOrderId,
        status: gelatoStatus,
      },
      updated_at: new Date().toISOString(),
    };

    console.info("[checkout:draft:18-persist-start]", {
      table: "checkout_drafts",
      userIdPresent: Boolean(authData.user.id),
      gelatoDraftOrderIdPresent: Boolean(gelatoDraftOrderId),
      cartItemCount: cartItemIds.length,
      idempotencyKeyPresent: Boolean(idempotencyKey),
      currency: matched.currency,
    });
    console.info("[checkout:draft:18-row]", {
      keys: Object.keys(draftRow),
      draftOrderIdPresent: Boolean((draftRow as { draft_order_id?: unknown }).draft_order_id),
      gelatoDraftOrderIdPresent: Boolean(draftRow.gelato_draft_order_id),
    });

    console.info("[checkout:draft:19-insert-start]");
    const { data: savedDraft, error: saveError } = await supabase
      .from("checkout_drafts")
      .upsert(draftRow, { onConflict: "idempotency_key" })
      .select("id, gelato_draft_order_id, status")
      .single();

    console.info("[checkout:draft:19-persist-result]", {
      hasData: Boolean(savedDraft),
      data: savedDraft,
      draftOrderId: savedDraft?.id ?? null,
      gelatoDraftOrderId: savedDraft?.gelato_draft_order_id ?? null,
      status: savedDraft?.status ?? null,
      error: saveError
        ? {
            code: saveError.code ?? null,
            message: saveError.message ?? null,
            details: saveError.details ?? null,
            hint: saveError.hint ?? null,
          }
        : null,
    });

    if (saveError || !savedDraft) {
      console.error("[checkout:draft:persist-failed]", {
        code: saveError?.code ?? null,
        message: saveError?.message ?? null,
        details: saveError?.details ?? null,
        hint: saveError?.hint ?? null,
      });
      const isMissingTable =
        saveError?.code === "42P01" ||
        /does not exist/i.test(saveError?.message ?? "") ||
        /does not exist/i.test(saveError?.details ?? "") ||
        /relation .*checkout_drafts/i.test(saveError?.message ?? "");
      return NextResponse.json(
        isMissingTable
          ? {
              success: false,
              code: "CHECKOUT_DRAFTS_TABLE_MISSING",
              message: "The checkout draft storage is not configured.",
            }
          : {
              success: false,
              code: "DRAFT_PERSIST_FAILED",
              message: "The draft was created but could not be saved.",
            },
        { status: isMissingTable ? 500 : 500 },
      );
    }

    log("[checkout:draft-created]", { draftOrderId: savedDraft.id });

    console.info("[checkout:draft:20-success-response]", {
      checkoutDraftId: savedDraft?.id ?? null,
      gelatoDraftOrderId,
    });

    return NextResponse.json({
      success: true,
      draftOrderId: savedDraft.id,
      gelatoDraftOrderId: savedDraft.gelato_draft_order_id ?? gelatoDraftOrderId,
      shippingMethod: {
        id: matched.id,
        code: matched.code,
        name: matched.name,
        price: matched.price,
        currency: matched.currency,
      },
      subtotal,
      shipping: matched.price,
      total: subtotal + matched.price,
      currency: matched.currency,
    });
  } catch (error) {
    console.error("[checkout:draft:99-unhandled]", {
      name: error instanceof Error ? error.name : null,
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : null,
    });
    return NextResponse.json(
      {
        success: false,
        code: "GELATO_DRAFT_FAILED",
        message: error instanceof Error ? error.message : "Unexpected checkout draft error.",
      },
      { status: 500 },
    );
  }
}
