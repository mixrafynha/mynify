import { NextResponse } from "next/server";
import disposable from "disposable-email-domains";
import { createClient } from "@supabase/supabase-js";

const requestLimit = new Map<string, number[]>();
const dailyLimit = new Map<string, number>();

const RATE_WINDOW = 60 * 1000;
const RATE_MAX = 5;
const DAILY_MAX = 3;

type SignupCode =
  | "created"
  | "account_exists"
  | "invalid_request"
  | "rate_limited"
  | "unavailable"
  | "failed";

function getIP(req: Request) {
  const forwardedFor = req.headers.get("x-forwarded-for");
  return (forwardedFor?.split(",")[0] || req.headers.get("x-real-ip") || "unknown").slice(0, 45);
}

function checkRateLimit(ip: string) {
  const now = Date.now();
  const logs = requestLimit.get(ip) || [];
  const recent = logs.filter((time) => now - time < RATE_WINDOW);

  if (recent.length >= RATE_MAX) return false;

  recent.push(now);
  requestLimit.set(ip, recent);

  return true;
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length < 254;
}

function isStrongPassword(password: string) {
  return (
    password.length >= 10 &&
    password.length <= 128 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /[0-9]/.test(password) &&
    /[^A-Za-z0-9]/.test(password)
  );
}

function getSafeOrigin(req: Request) {
  const fallback =
    process.env.NEXT_PUBLIC_SITE_URL ||
    process.env.NEXT_PUBLIC_APP_URL ||
    "https://www.ryfio.com";

  const origin = req.headers.get("origin") || fallback;

  try {
    const url = new URL(origin);

    if (url.protocol !== "https:" && url.hostname !== "localhost") {
      return fallback;
    }

    return url.origin;
  } catch {
    return fallback;
  }
}

function hasNoNewIdentity(data: unknown) {
  const user = (data as { user?: { identities?: unknown[] } | null } | null)?.user;
  if (!user) return false;
  if (!Array.isArray(user.identities)) return false;
  return user.identities.length === 0;
}

function json(code: SignupCode, message: string, status: number) {
  return NextResponse.json({ code, message }, { status });
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => null);
    if (!body || typeof body !== "object") {
      return json("invalid_request", "Invalid request.", 400);
    }

    const email = String((body as { email?: unknown }).email ?? "")
      .trim()
      .toLowerCase();

    const password = String((body as { password?: unknown }).password ?? "");
    const token = String((body as { token?: unknown }).token ?? "");
    const ip = getIP(req);

    if (!checkRateLimit(ip)) {
      return json("rate_limited", "Too many requests. Try again later.", 429);
    }

    if (!token || !isValidEmail(email) || !isStrongPassword(password)) {
      return json("invalid_request", "Invalid request.", 400);
    }

    const domain = email.split("@")[1];

    if (!domain || disposable.includes(domain)) {
      return json("invalid_request", "Invalid request.", 400);
    }

    const day = new Date().toISOString().slice(0, 10);
    const key = `${ip}-${day}`;
    const used = dailyLimit.get(key) || 0;

    if (used >= DAILY_MAX) {
      return json("rate_limited", "Too many accounts today. Try again tomorrow.", 429);
    }

    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

    if (!supabaseUrl || !supabaseAnonKey) {
      return json("unavailable", "Signup is temporarily unavailable.", 503);
    }

    const origin = getSafeOrigin(req);
    const supabase = createClient(supabaseUrl, supabaseAnonKey);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        captchaToken: token,
        emailRedirectTo: `${origin}/auth/callback`,
      },
    });

    if (error) {
      const message = error.message.toLowerCase();
      const isExisting =
        message.includes("already") ||
        message.includes("registered") ||
        message.includes("exists") ||
        message.includes("user");

      if (isExisting) {
        return json("account_exists", "This email is already registered. Log in instead.", 409);
      }

      return json("failed", "Unable to create account.", 400);
    }

    if (hasNoNewIdentity(data)) {
      return json("account_exists", "This email is already registered. Log in instead.", 409);
    }

    dailyLimit.set(key, used + 1);

    return json("created", "Account created. Check your email to confirm your account.", 201);
  } catch {
    return json("unavailable", "Signup is temporarily unavailable.", 500);
  }
}
