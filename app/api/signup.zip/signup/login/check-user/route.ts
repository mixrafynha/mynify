import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const requestLimit = new Map<string, number[]>();
const RATE_WINDOW = 60 * 1000;
const RATE_MAX = 20;

function getIP(req: Request) {
  const forwardedFor = req.headers.get("x-forwarded-for");
  return (forwardedFor?.split(",")[0] || "unknown").slice(0, 45);
}

function checkRateLimit(ip: string) {
  const now = Date.now();
  const logs = requestLimit.get(ip) || [];
  const recent = logs.filter((time) => now - time < RATE_WINDOW);

  if (recent.length >= RATE_MAX) return false;

  recent.push(now);
  requestLimit.set(ip, recent);

  return true;
}

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length < 254;
}

async function sendLoginCheckLog(
  req: Request,
  input: {
    event: "login_check_user_found" | "login_check_user_not_found" | "login_check_failed";
    level: "info" | "warn" | "error";
    email: string;
    reason?: string;
    status?: number;
  }
) {
  try {
    await fetch(new URL("/api/logs", req.url), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        event: input.event,
        type: input.event,
        level: input.level,
        source: "web.auth.login.server",
        product: "Ryfio",
        timestamp: new Date().toISOString(),
        emailDomain: input.email.split("@")[1] ?? null,
        reason: input.reason ?? null,
        status: input.status ?? null,
        ip: getIP(req),
        userAgent: req.headers.get("user-agent") ?? null,
      }),
    });
  } catch {
    // Logs must never block auth.
  }
}

async function userExistsByEmail(email: string) {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) return null;

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });

  for (let page = 1; page <= 10; page += 1) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 1000 });

    if (error) throw error;

    const found = data.users.some((user) => user.email?.toLowerCase() === email);
    if (found) return true;

    if (data.users.length < 1000) return false;
  }

  return null;
}

export async function POST(req: Request) {
  try {
    const ip = getIP(req);

    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { ok: false, code: "rate_limited", message: "Too many attempts. Try again later." },
        { status: 429 }
      );
    }

    const body = await req.json().catch(() => null);
    const email = String((body as { email?: unknown } | null)?.email ?? "")
      .trim()
      .toLowerCase();

    if (!isValidEmail(email)) {
      return NextResponse.json(
        { ok: false, code: "failed", message: "Invalid request." },
        { status: 400 }
      );
    }

    const exists = await userExistsByEmail(email);

    if (exists === false) {
      await sendLoginCheckLog(req, {
        event: "login_check_user_not_found",
        level: "warn",
        email,
        reason: "user_not_found_before_password_auth",
        status: 404,
      });

      return NextResponse.json(
        { ok: false, code: "user_not_found", message: "No account exists with this email." },
        { status: 404 }
      );
    }

    if (exists === true) {
      await sendLoginCheckLog(req, {
        event: "login_check_user_found",
        level: "info",
        email,
        reason: "user_exists_before_password_auth",
        status: 200,
      });
    }

    return NextResponse.json({ ok: true, code: "ok" }, { status: 200 });
  } catch (error) {
    await sendLoginCheckLog(req, {
      event: "login_check_failed",
      level: "error",
      email: "unknown@unknown.local",
      reason: error instanceof Error ? error.message.slice(0, 160) : "unknown_error",
      status: 200,
    });

    return NextResponse.json({ ok: true, code: "unchecked" }, { status: 200 });
  }
}
