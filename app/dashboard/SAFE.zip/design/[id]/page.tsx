"use client";

import { useState, useRef, useEffect, useMemo, useCallback } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";

import Canvas from "@/app/dashboard/design/components/Canvas";
import TopBar from "@/app/dashboard/design/components/TopBar";
import EditorShell from "@/app/dashboard/design/components/EditorShell";
import ToolbarFAB from "@/app/dashboard/design/components/toolbar/ToolbarFAB";
import AuthPopup from "@/app/dashboard/design/components/toolbar/panels/AuthPopup";
import { captureProductionPreview } from "@/app/dashboard/design/components/preview/services/previewCapture";
import { buildDesignSavePayload } from "@/app/dashboard/design/components/topbar/services/designSavePayload";

import { useElements } from "@/features/elements/useElements";
import { useUpload } from "@/features/upload/useUpload";

export type ElementType = {
  id: string;
  type: "image" | "text" | "shape";
  src?: string;
  text?: string;
  x: number;
  y: number;
  width?: number;
  height?: number;
  meta?: {
    fontSize?: number;
    fontFamily?: string;
    color?: string;
    [key: string]: any;
  };
};

type Side = "front" | "back";

type HistoryState = {
  frontElements: ElementType[];
  backElements: ElementType[];
};

type EditorVariantSelection = {
  variantId: string | null;
  productColorId: string | null;
  colorId: string | null;
  size: string | null;
  colorName: string | null;
  colorHex: string | null;
  sku: string | null;
  price: string | null;
  variantPrice: string | null;
  image: string | null;
  imageUrl: string | null;
};

type SearchParamReader = { get: (name: string) => string | null };

function readSearchParam(params: SearchParamReader, keys: string[]) {
  for (const key of keys) {
    const value = params.get(key);
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return null;
}

function buildVariantSelection(
  params: SearchParamReader,
): EditorVariantSelection | null {
  const variantId = readSearchParam(params, [
    "variantId",
    "variant_id",
    "selectedVariantId",
  ]);
  const productColorId = readSearchParam(params, [
    "productColorId",
    "product_color_id",
    "colorId",
    "color_id",
  ]);
  const size = readSearchParam(params, ["size", "variantSize"]);
  const colorName = readSearchParam(params, [
    "colorName",
    "color",
    "variantColor",
  ]);
  const colorHex = readSearchParam(params, ["colorHex", "hex", "mockupColor"]);
  const sku = readSearchParam(params, ["sku", "variantSku"]);
  const price = readSearchParam(params, ["variantPrice", "price"]);
  const image = readSearchParam(params, ["variantImage", "image", "imageUrl"]);

  if (
    !variantId &&
    !productColorId &&
    !size &&
    !colorName &&
    !colorHex &&
    !sku &&
    !price &&
    !image
  ) {
    return null;
  }

  return {
    variantId,
    productColorId,
    colorId: productColorId,
    size,
    colorName,
    colorHex,
    sku,
    price,
    variantPrice: price,
    image,
    imageUrl: image,
  };
}

export default function EditorPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const router = useRouter();
  const productId =
    searchParams.get("productId") || searchParams.get("baseProductId");
  const category = String(params?.id || "tshirt").toLowerCase();
  const selectedVariant = useMemo(
    () => buildVariantSelection(searchParams),
    [searchParams],
  );

  const fileRef = useRef<HTMLInputElement>(null);
  const previewCanvasRef = useRef<HTMLDivElement>(null);
  const hasLoadedDraft = useRef(false);
  const isHistoryAction = useRef(false);
  const pendingSaveAfterAuthRef = useRef(false);

  const editorStorageKey = useMemo(
    () =>
      `editor-design:${productId || category || "draft"}:${selectedVariant?.variantId || "default"}`,
    [productId, category, selectedVariant?.variantId],
  );

  const [side, setSide] = useState<Side>("front");
  const [saving, setSaving] = useState(false);
  const [authPopupOpen, setAuthPopupOpen] = useState(false);
  const [saveNotice, setSaveNotice] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedElement, setSelectedElement] = useState<ElementType | null>(
    null,
  );

  const [zoom, setZoom] = useState(1);
  const [mockupColor, setMockupColor] = useState(
    selectedVariant?.colorHex || "#ffffff",
  );

  const [frontElements, setFrontElements] = useState<ElementType[]>([]);
  const [backElements, setBackElements] = useState<ElementType[]>([]);

  useEffect(() => {
    if (selectedVariant?.colorHex && !hasLoadedDraft.current) {
      setMockupColor(selectedVariant.colorHex);
    }
  }, [selectedVariant?.colorHex]);

  useEffect(() => {
    const preventGesture = (event: Event) => {
      event.preventDefault();
    };

    const preventMultiTouch = (event: TouchEvent) => {
      if (event.touches.length > 1) event.preventDefault();
    };

    const preventEditorDoubleTapZoom = (event: MouseEvent) => {
      const target = event.target as Element | null;
      if (target?.closest("[data-ryfio-editor-root]")) event.preventDefault();
    };

    document.addEventListener("gesturestart", preventGesture, {
      passive: false,
    } as AddEventListenerOptions);
    document.addEventListener("gesturechange", preventGesture, {
      passive: false,
    } as AddEventListenerOptions);
    document.addEventListener("gestureend", preventGesture, {
      passive: false,
    } as AddEventListenerOptions);
    document.addEventListener("touchmove", preventMultiTouch, {
      passive: false,
    });
    document.addEventListener("dblclick", preventEditorDoubleTapZoom, {
      passive: false,
    });

    return () => {
      document.removeEventListener("gesturestart", preventGesture);
      document.removeEventListener("gesturechange", preventGesture);
      document.removeEventListener("gestureend", preventGesture);
      document.removeEventListener("touchmove", preventMultiTouch);
      document.removeEventListener("dblclick", preventEditorDoubleTapZoom);
    };
  }, []);

  const [history, setHistory] = useState<HistoryState[]>([]);
  const [future, setFuture] = useState<HistoryState[]>([]);

  const elements = side === "back" ? backElements : frontElements;
  const setElements = side === "back" ? setBackElements : setFrontElements;

  const { addText, addElement } = useElements({
    setElements,
    selectedId,
  });

  const uploadImage = useUpload(addElement);

  const handleUploadChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = "";

      if (!file) return;

      uploadImage(file);
    },
    [uploadImage],
  );

  const zoomIn = useCallback(() => {
    setZoom((z) => Math.min(1.35, z + 0.1));
  }, []);

  const zoomOut = useCallback(() => {
    setZoom((z) => Math.max(0.75, z - 0.1));
  }, []);

  const saveDraftToSession = useCallback(() => {
    try {
      sessionStorage.setItem(
        editorStorageKey,
        JSON.stringify({
          side,
          zoom,
          mockupColor,
          frontElements,
          backElements,
          selectedVariant,
          updatedAt: Date.now(),
        }),
      );
    } catch {
      // Ignore storage failures so the editor remains usable.
    }
  }, [
    editorStorageKey,
    side,
    zoom,
    mockupColor,
    frontElements,
    backElements,
    selectedVariant,
  ]);

  useEffect(() => {
    try {
      const saved = sessionStorage.getItem(editorStorageKey);

      if (!saved) {
        setHistory([{ frontElements: [], backElements: [] }]);
        hasLoadedDraft.current = true;
        return;
      }

      const parsed = JSON.parse(saved);

      const loadedFront = Array.isArray(parsed.frontElements)
        ? parsed.frontElements
        : [];
      const loadedBack = Array.isArray(parsed.backElements)
        ? parsed.backElements
        : [];

      if (parsed.side === "front" || parsed.side === "back") {
        setSide(parsed.side);
      }

      if (typeof parsed.zoom === "number") {
        setZoom(Math.min(2, Math.max(0.4, parsed.zoom)));
      }

      if (typeof parsed.mockupColor === "string") {
        setMockupColor(parsed.mockupColor);
      }

      setFrontElements(loadedFront);
      setBackElements(loadedBack);

      setHistory([{ frontElements: loadedFront, backElements: loadedBack }]);
    } finally {
      hasLoadedDraft.current = true;
    }
  }, [editorStorageKey]);

  const handleSaveDesign = useCallback(async () => {
    if (saving) return;

    const baseProductId = productId || category;

    if (!baseProductId) {
      alert(
        "Product missing. Open the editor from a product page before saving.",
      );
      return;
    }

    try {
      setSaving(true);
      setSaveNotice(null);
      saveDraftToSession();

      const designPayload = await buildDesignSavePayload({
        productId: baseProductId,
        category,
        side,
        elements,
        frontElements,
        backElements,
        mockupColor,
        color: mockupColor,
        variantId: selectedVariant?.variantId || null,
        selectedVariant,
      });

      const response = await fetch("/api/user-products/save-design", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(designPayload),
      });

      const rawResponseText = await response.text().catch(() => "");
      let data: any = null;
      try {
        data = rawResponseText ? JSON.parse(rawResponseText) : null;
      } catch {
        data = null;
      }

      if (response.status === 401) {
        pendingSaveAfterAuthRef.current = true;
        setSaveNotice(null);
        setAuthPopupOpen(true);
        return;
      }

      if (!response.ok) {
        const serverMessage =
          data?.error ||
          data?.message ||
          rawResponseText?.slice(0, 500) ||
          response.statusText ||
          "Failed to save design";

        throw new Error(
          `/api/user-products/save-design failed (${response.status}): ${serverMessage}`,
        );
      }

      sessionStorage.removeItem(editorStorageKey);
      setSaveNotice(
        "Design saved successfully. Redirecting you to checkout...",
      );

      const checkoutUrl = data?.designId
        ? `/checkout?designId=${data.designId}`
        : "/checkout";
      router.push(checkoutUrl);
      return;
    } catch {
      alert("Error saving design");
    } finally {
      setSaving(false);
    }
  }, [
    productId,
    category,
    side,
    elements,
    saving,
    saveDraftToSession,
    frontElements,
    backElements,
    mockupColor,
    selectedVariant,
    editorStorageKey,
    router,
  ]);

  const handleAuthSuccess = useCallback(() => {
    setAuthPopupOpen(false);

    if (!pendingSaveAfterAuthRef.current) return;

    pendingSaveAfterAuthRef.current = false;
    window.setTimeout(() => {
      void handleSaveDesign();
    }, 250);
  }, [handleSaveDesign]);

  const handlePreviewDesign = useCallback(async (): Promise<void> => {
    try {
      saveDraftToSession();

      if (!previewCanvasRef.current) {
        return;
      }

      const exportNode = previewCanvasRef.current.querySelector(
        "#mockup-export-root",
      ) as HTMLElement | null;

      if (!exportNode) {
        return;
      }

      const designImage = await captureProductionPreview(exportNode);

      if (
        typeof designImage !== "string" ||
        !designImage.startsWith("data:image/")
      ) {
        return;
      }

      // Se precisares de usar a imagem, guarda-a num estado:
      // setPreviewImage(designImage);

      return;
    } catch {
      return;
    }
  }, [saveDraftToSession]);
  useEffect(() => {
    if (!hasLoadedDraft.current || isHistoryAction.current) return;

    const snapshot = { frontElements, backElements };
    const serialized = JSON.stringify(snapshot);
    const last = history[history.length - 1];

    if (last && JSON.stringify(last) === serialized) return;

    setHistory((prev) => {
      const previous = prev[prev.length - 1];
      if (previous && JSON.stringify(previous) === serialized) return prev;
      return [...prev, snapshot].slice(-80);
    });
    setFuture([]);
  }, [frontElements, backElements, history]);

  const applyHistoryState = useCallback((state: HistoryState) => {
    isHistoryAction.current = true;
    setFrontElements(state.frontElements || []);
    setBackElements(state.backElements || []);
    setSelectedId(null);
    setSelectedElement(null);
    queueMicrotask(() => {
      isHistoryAction.current = false;
    });
  }, []);

  const handleUndo = useCallback(() => {
    setHistory((prev) => {
      if (prev.length <= 1) return prev;
      const current = prev[prev.length - 1];
      const previous = prev[prev.length - 2];
      setFuture((next) => [current, ...next].slice(0, 80));
      applyHistoryState(previous);
      return prev.slice(0, -1);
    });
  }, [applyHistoryState]);

  const handleRedo = useCallback(() => {
    setFuture((prev) => {
      if (!prev.length) return prev;
      const [next, ...rest] = prev;
      setHistory((historyPrev) => [...historyPrev, next].slice(-80));
      applyHistoryState(next);
      return rest;
    });
  }, [applyHistoryState]);

  const handleRevert = useCallback(() => {
    const empty = { frontElements: [], backElements: [] };
    applyHistoryState(empty);
    setHistory([empty]);
    setFuture([]);
    saveDraftToSession();
  }, [applyHistoryState, saveDraftToSession]);

  return (
    <>
      <EditorShell
        sidebar={null}
        topbar={
          <TopBar
            productId={productId || undefined}
            category={category}
            side={side}
            setSide={setSide}
            zoomIn={zoomIn}
            zoomOut={zoomOut}
            zoom={Math.round(zoom * 100)}
            onSaveDesign={handleSaveDesign}
            onPreviewDesign={handlePreviewDesign}
            onUndo={handleUndo}
            onRedo={handleRedo}
            onRevert={handleRevert}
            canUndo={history.length > 1}
            canRedo={future.length > 0}
            saving={saving}
            elements={elements}
            frontElements={frontElements}
            backElements={backElements}
            mockupColor={mockupColor}
          />
        }
        canvas={
          <Canvas
            side={side}
            elements={elements}
            setElements={setElements}
            zoom={zoom}
            selectedId={selectedId}
            setSelectedId={setSelectedId}
            setSelectedElement={setSelectedElement}
            mockupColor={mockupColor}
            setMockupColor={setMockupColor}
            canvasRef={previewCanvasRef}
          />
        }
        toolbar={
          <ToolbarFAB
            onUpload={uploadImage}
            onUploadClick={() => {
              if (!fileRef.current) return;
              fileRef.current.value = "";
              fileRef.current.click();
            }}
            onAddText={addText}
            setElements={setElements}
            elements={elements}
            selectedId={selectedId}
            zoomIn={zoomIn}
            zoomOut={zoomOut}
          />
        }
      />

      <input
        ref={fileRef}
        type="file"
        hidden
        accept="image/png,image/jpeg,image/webp"
        onChange={handleUploadChange}
      />

      {saveNotice && (
        <div className="pointer-events-none fixed left-1/2 top-16 z-[998] w-[calc(100%-2rem)] max-w-[360px] -translate-x-1/2 rounded-2xl border border-white/10 bg-[#090914]/95 px-4 py-3 text-center text-sm font-bold text-white shadow-[0_18px_60px_rgba(0,0,0,0.45)] backdrop-blur-xl">
          {saveNotice}
        </div>
      )}

      {authPopupOpen && (
        <div className="fixed inset-0 z-[999]">
          <AuthPopup
            open={authPopupOpen}
            onClose={() => {
              pendingSaveAfterAuthRef.current = false;
              setAuthPopupOpen(false);
            }}
            onSuccess={handleAuthSuccess}
          />
        </div>
      )}
    </>
  );
}
