import { getPrintBox, getSafeArea } from "../../canvas/canvasMath";
import { capturePreviewDesignOverlay } from "../../preview/services/previewCapture";
import type { PreviewPayloadInput } from "../types";

const PRODUCT_ALIASES: Record<string, string> = {
  "t-shirt": "tshirt",
  tshirts: "tshirt",
  tee: "tshirt",
  shirt: "tshirt",
  sweat: "hoodie",
  sweatshirt: "hoodie",
  hat: "cap",
  cup: "mug",
};

type Side = "front" | "back";

function normalizeCategory(value?: string) {
  const raw = String(value || "tshirt")
    .toLowerCase()
    .trim()
    .replace(/\s+/g, "-");

  const withoutUuid = /^[0-9a-f]{8}-[0-9a-f]{4}/i.test(raw) ? "tshirt" : raw;
  return PRODUCT_ALIASES[withoutUuid] || withoutUuid || "tshirt";
}

function elementsForSide(input: PreviewPayloadInput, side: Side) {
  const sideElements =
    side === "back" ? input.backElements : input.frontElements;

  if (Array.isArray(sideElements) && sideElements.length) {
    return sideElements;
  }

  if (input.side === side && Array.isArray(input.elements)) {
    return input.elements;
  }

  return [];
}

function sanitizeElementsForStorage(elements: any[]) {
  return (Array.isArray(elements) ? elements : []).map((element) => {
    const meta = { ...(element?.meta || {}) };

    delete meta.src;
    delete meta.image;
    delete meta.url;

    return {
      ...element,
      src:
        typeof element?.src === "string" &&
        element.src.startsWith("data:image/")
          ? undefined
          : element?.src,
      meta,
    };
  });
}

function sideData(input: PreviewPayloadInput, category: string, side: Side) {
  const sidePrintBox = input.printBoxes?.[side] || null;
  const sideSafeArea = input.safeAreas?.[side] || null;
  const printBox =
    sidePrintBox ||
    (input.side === side && input.printBox ? input.printBox : null) ||
    getPrintBox(category, side);
  const safeArea =
    sideSafeArea ||
    (input.side === side && input.safeArea ? input.safeArea : null) ||
    getSafeArea(printBox);
  const elements = elementsForSide(input, side);

  return {
    side,
    elements,
    mockupUrl: "",
    printBox,
    safeArea,
    printSize: {
      widthMm: 0,
      heightMm: 0,
    },
    exportResolution: {
      width: 1024,
      height: 1024,
    },
    validation: {
      status: "ready" as const,
      statusLabel: "Ready",
      dpi: null,
      warnings: [],
      printReady: true,
      riskLevel: "low" as const,
    },
  };
}

export async function buildPreviewPayload(input: PreviewPayloadInput) {
  const category = normalizeCategory(input.category);
  const productId = input.productId || category;
  const side: Side = input.side === "back" ? "back" : "front";

  const frontRawElements = elementsForSide(input, "front");
  const backRawElements = elementsForSide(input, "back");
  const currentElements = side === "back" ? backRawElements : frontRawElements;

  const currentSideData = sideData(input, category, side);
  const frontSideData = sideData(input, category, "front");
  const backSideData = sideData(input, category, "back");

  console.log("PREVIEW BUILD START", {
    productId,
    category,
    side,
    frontElements: frontRawElements.length,
    backElements: backRawElements.length,
  });

  const currentDesignImage = await capturePreviewDesignOverlay(currentSideData);

  const frontDesignImage =
    side === "front"
      ? currentDesignImage
      : input.designImages?.front || null;

  const backDesignImage =
    side === "back"
      ? currentDesignImage
      : input.designImages?.back || null;

  const printBox = currentSideData.printBox;
  const safeArea = currentSideData.safeArea;
  const frontElements = sanitizeElementsForStorage(frontRawElements);
  const backElements = sanitizeElementsForStorage(backRawElements);
  const storedCurrentElements = side === "back" ? backElements : frontElements;

  const payload = {
    productId,
    category,
    color: input.color || input.mockupColor,
    mockupColor: input.mockupColor || input.color || "#ffffff",
    side,

    elements: storedCurrentElements,
    frontElements,
    backElements,

    printBox,
    safeArea,
    printBoxes: {
      front: frontSideData.printBox,
      back: backSideData.printBox,
    },
    safeAreas: {
      front: frontSideData.safeArea,
      back: backSideData.safeArea,
    },

    designImage: side === "back" ? backDesignImage : frontDesignImage,
    designImages: {
      front: frontDesignImage,
      back: backDesignImage,
    },

    designCoordinateMode: "safe-area-local",
    designImageMode: currentDesignImage
      ? "visual-preview-overlay-1024"
      : "missing-design-image",

    generateMockupAI: true,
    updatedAt: Date.now(),
  };

  console.log("FINAL PAYLOAD", {
    side,
    hasDesignImage: !!payload.designImage,
    hasFrontDesignImage: !!payload.designImages.front,
    hasBackDesignImage: !!payload.designImages.back,
    frontPrintBox: payload.printBoxes.front,
    backPrintBox: payload.printBoxes.back,
    designImageLength:
      typeof payload.designImage === "string"
        ? payload.designImage.length
        : null,
  });

  return payload;
}

function makeStorageSafePayload(payload: any) {
  return {
    ...payload,
    designImage: null,
    designImages: {
      front: null,
      back: null,
    },
    designImageMode: payload?.designImageMode
      ? `${payload.designImageMode}-memory-only`
      : "memory-only",
  };
}

function safeSetStorage(storage: Storage, key: string, payload: any) {
  try {
    storage.setItem(key, JSON.stringify(payload));
    return true;
  } catch (error) {
    console.warn("PREVIEW STORAGE FULL; RETRYING WITHOUT INLINE DATA IMAGES", error);
  }

  try {
    storage.setItem(key, JSON.stringify(makeStorageSafePayload(payload)));
    return true;
  } catch (error) {
    console.warn("PREVIEW STORAGE SKIPPED", error);
    return false;
  }
}

export async function storePreviewPayload(input: PreviewPayloadInput) {
  if (typeof window === "undefined") {
    console.error("WINDOW UNDEFINED");
    return null;
  }

  const payload = await buildPreviewPayload(input);
  const key = `ryfio-editor-preview:${payload.productId}`;

  const sessionStored = safeSetStorage(sessionStorage, key, payload);
  const localStored = safeSetStorage(localStorage, key, payload);

  console.log("PREVIEW STORED", {
    key,
    sessionStored,
    localStored,
    hasDesignImage: !!payload.designImage,
    hasFrontDesignImage: !!payload.designImages.front,
    hasBackDesignImage: !!payload.designImages.back,
    frontPrintBox: payload.printBoxes.front,
    backPrintBox: payload.printBoxes.back,
  });

  return payload;
}
