"use client";

import {
  memo,
  useCallback,
  useDeferredValue,
  useMemo,
  useRef,
  useState,
  type SyntheticEvent,
} from "react";
import { Search, Star, Type } from "lucide-react";
import {
  FONT_CATEGORIES,
  FONT_ITEMS,
  loadEditorFont,
  useEditorFontCatalog,
  getFontPreviewUrl,
  type FontCategory,
  type FontItem,
} from "../data";

const FAVORITES_KEY = "ryfio-editor-favorite-fonts";
const RECENTS_KEY = "ryfio-editor-recent-fonts";
const DESKTOP_PAGE_SIZE = 12;
const MOBILE_PAGE_SIZE = 8;
const MAX_RECENTS = 24;
const MAX_STORED_FAVORITES = 80;

function isMobileViewport() {
  if (typeof window === "undefined") return false;
  return window.matchMedia?.("(max-width: 767px)").matches ?? false;
}

function getPageSize() {
  return isMobileViewport() ? MOBILE_PAGE_SIZE : DESKTOP_PAGE_SIZE;
}

const PRIORITY_FONT_IDS = [
  "inter",
  "bebas-neue",
  "anton",
  "great-vibes",
  "dancing-script",
  "playfair-display",
  "pacifico",
  "orbitron",
  "black-ops-one",
  "archivo-black",
  "montserrat",
  "lora",
  "cinzel",
  "caveat",
  "oswald",
  "space-grotesk",
  "manrope",
  "sora",
  "rubik",
  "league-spartan",
];

const CATEGORY_ORDER: FontCategory[] = [
  "minimalist",
  "luxury",
  "sporty",
  "handwritten",
  "display",
  "sans",
  "serif",
  "streetwear",
  "retro",
  "kids",
];

function uniqueFamilyKey(value: string) {
  return value.trim().toLowerCase();
}

function uniqueFamilies(values: string[]) {
  const seen = new Set<string>();

  return values.filter((value) => {
    const key = uniqueFamilyKey(value);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function dedupeFontsByFamily(fonts: FontItem[]) {
  const seen = new Set<string>();

  return fonts.filter((font) => {
    const key = uniqueFamilyKey(font.family);
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function mixFontsByCategory(fonts: FontItem[]) {
  const buckets = new Map<FontCategory, FontItem[]>();
  CATEGORY_ORDER.forEach((category) => buckets.set(category, []));

  fonts.forEach((font) => {
    const bucket = buckets.get(font.category) ?? [];
    bucket.push(font);
    buckets.set(font.category, bucket);
  });

  const mixed: FontItem[] = [];
  let hasFonts = true;

  while (hasFonts) {
    hasFonts = false;

    CATEGORY_ORDER.forEach((category) => {
      const bucket = buckets.get(category);
      const next = bucket?.shift();

      if (next) {
        mixed.push(next);
        hasFonts = true;
      }
    });
  }

  return mixed;
}

function sortFontsForDiscovery(fonts: FontItem[]) {
  const priority = new Map(PRIORITY_FONT_IDS.map((id, index) => [id, index]));
  const priorityFonts: FontItem[] = [];
  const remainingFonts: FontItem[] = [];

  fonts.forEach((font) => {
    if (priority.has(font.id)) priorityFonts.push(font);
    else remainingFonts.push(font);
  });

  priorityFonts.sort((a, b) => {
    return (priority.get(a.id) ?? 9999) - (priority.get(b.id) ?? 9999);
  });

  return dedupeFontsByFamily([...priorityFonts, ...mixFontsByCategory(remainingFonts)]);
}

function readStorage(key: string) {
  if (typeof window === "undefined") return [] as string[];

  try {
    const parsed = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(parsed)
      ? uniqueFamilies(parsed.filter(Boolean).map(String))
      : [];
  } catch {
    return [] as string[];
  }
}

function writeStorage(key: string, value: string[], max = 40) {
  if (typeof window === "undefined") return;
  localStorage.setItem(key, JSON.stringify(uniqueFamilies(value).slice(0, max)));
}

function getFontPreviewSrc(font: FontItem) {
  return getFontPreviewUrl(font);
}

function hideBrokenPreview(event: SyntheticEvent<HTMLImageElement>) {
  event.currentTarget.style.display = "none";
}

function buildTextElement(font: FontItem) {
  const text = "RYFIO";
  const fontSize = 42;
  const width = 220;
  const height = 68;

  return {
    type: "text",
    text,
    content: text,
    width,
    height,
    fontFamily: font.family,
    fontSize,
    fontWeight: 800,
    color: "#111111",
    meta: {
      fontFamily: font.family,
      fontSize,
      fontWeight: 800,
      color: "#111111",
      letterSpacing: 0,
      lineHeight: 1.15,
      textAlign: "center",
      textShape: "straight",
      opacity: 1,
      rotation: 0,
    },
  };
}

function TextPanel({
  createElement,
  onAddText,
}: {
  createElement?: (element: any) => void;
  onAddText?: () => void;
}) {
  const lockedRef = useRef(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<
    FontCategory | "all" | "favorites" | "recent"
  >("all");
  const [favorites, setFavorites] = useState<string[]>(() =>
    readStorage(FAVORITES_KEY),
  );
  const [recents, setRecents] = useState<string[]>(() =>
    readStorage(RECENTS_KEY),
  );
  const [limit, setLimit] = useState(() => getPageSize());

  const { fonts: liveFonts } = useEditorFontCatalog();

  const visibleCatalogFonts = useMemo(() => {
    return sortFontsForDiscovery(
      dedupeFontsByFamily(liveFonts.length ? liveFonts : FONT_ITEMS),
    );
  }, [liveFonts]);

  const deferredQuery = useDeferredValue(query);

  const allFilteredFonts = useMemo(() => {
    const term = deferredQuery.trim().toLowerCase();
    let source: FontItem[] = visibleCatalogFonts;

    if (category === "favorites") {
      source = visibleCatalogFonts.filter((font) =>
        favorites.includes(font.family),
      );
    } else if (category === "recent") {
      source = visibleCatalogFonts.filter((font) =>
        recents.includes(font.family),
      );
    } else if (category !== "all") {
      source = visibleCatalogFonts.filter((font) => font.category === category);
    }

    if (!term) return source;

    return source.filter((font) =>
      `${font.family} ${font.category} ${font.id}`.toLowerCase().includes(term),
    );
  }, [category, deferredQuery, favorites, recents, visibleCatalogFonts]);

  const filteredFonts = useMemo(
    () => allFilteredFonts.slice(0, limit),
    [allFilteredFonts, limit],
  );

  const markRecent = useCallback(
    (family: string) => {
      const next = [family, ...recents.filter((item) => item !== family)].slice(
        0,
        MAX_RECENTS,
      );
      setRecents(next);
      writeStorage(RECENTS_KEY, next, MAX_RECENTS);
    },
    [recents],
  );

  const toggleFavorite = useCallback(
    (family: string) => {
      const next = favorites.includes(family)
        ? favorites.filter((item) => item !== family)
        : [family, ...favorites].slice(0, MAX_STORED_FAVORITES);

      setFavorites(next);
      writeStorage(FAVORITES_KEY, next, MAX_STORED_FAVORITES);
    },
    [favorites],
  );

  const addFont = useCallback(
    async (font: FontItem) => {
      if (lockedRef.current) return;
      lockedRef.current = true;

      try {
        await loadEditorFont(font);
        markRecent(font.family);
        createElement?.(buildTextElement(font));
      } finally {
        window.setTimeout(() => {
          lockedRef.current = false;
        }, 160);
      }
    },
    [createElement, markRecent],
  );

  const changeCategory = useCallback(
    (item: FontCategory | "all" | "favorites" | "recent") => {
      setCategory(item);
      setLimit(getPageSize());
    },
    [],
  );

  const addDefaultText = useCallback(() => {
    const first =
      filteredFonts[0] || allFilteredFonts[0] || visibleCatalogFonts[0];
    if (first) void addFont(first);
  }, [addFont, allFilteredFonts, filteredFonts, visibleCatalogFonts]);

  return (
    <div
      className="flex h-full min-h-0 flex-col text-white"
      style={{ contain: "layout paint style" }}
    >
      <div className="shrink-0 space-y-3 pb-3">
        <button
          type="button"
          onClick={onAddText || addDefaultText}
          className="flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-violet-500 px-4 text-sm font-black text-white shadow-lg shadow-violet-950/25 active:scale-[0.99]"
        >
          <Type size={17} /> Add text
        </button>

        <PanelLabel title="Fonts" count={allFilteredFonts.length} />

        <label className="flex h-11 items-center gap-2 rounded-2xl bg-white/[0.055] px-3 text-slate-400 ring-1 ring-white/10 focus-within:ring-violet-400/60">
          <Search size={15} />
          <input
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setLimit(getPageSize());
            }}
            placeholder={`Search ${visibleCatalogFonts.length}+ fonts`}
            className="min-w-0 flex-1 bg-transparent text-sm font-semibold text-white outline-none placeholder:text-slate-600"
          />
        </label>

        <div className="flex gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          {(["all", "favorites", "recent", ...FONT_CATEGORIES] as const).map(
            (item) => (
              <button
                key={item}
                type="button"
                onClick={() => changeCategory(item)}
                className={`shrink-0 rounded-full px-3 py-2 text-xs font-black capitalize transition-colors active:scale-95 ${
                  category === item
                    ? "bg-violet-500 text-white"
                    : "bg-white/[0.045] text-slate-400 ring-1 ring-white/10"
                }`}
              >
                {item}
              </button>
            ),
          )}
        </div>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto pr-0.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
        <div className="flex flex-col gap-2">
          {filteredFonts.map((font) => (
            <FontCard
              key={font.id}
              font={font}
              favorite={favorites.includes(font.family)}
              onAdd={() => addFont(font)}
              onToggleFavorite={() => toggleFavorite(font.family)}
            />
          ))}
        </div>

        {!filteredFonts.length && (
          <div className="rounded-2xl border border-white/10 bg-white/[0.035] px-4 py-6 text-center text-sm font-bold text-white/50">
            No fonts found.
          </div>
        )}

        {limit < allFilteredFonts.length && (
          <button
            type="button"
            onClick={() => setLimit((value) => value + getPageSize())}
            className="mt-3 h-11 w-full rounded-2xl bg-white/[0.055] text-xs font-black text-slate-300 ring-1 ring-white/10 active:scale-[0.98]"
          >
            Load more fonts
          </button>
        )}
      </div>
    </div>
  );
}

const FontCard = memo(function FontCard({
  font,
  favorite,
  onAdd,
  onToggleFavorite,
}: {
  font: FontItem;
  favorite: boolean;
  onAdd: () => void;
  onToggleFavorite: () => void;
}) {
  const previewSrc = getFontPreviewSrc(font);

  return (
    <div
      className="group relative overflow-hidden rounded-2xl bg-[#171722] ring-1 ring-white/10 transition active:scale-[0.985]"
      style={{ contain: "layout paint style" }}
    >
      <button
        type="button"
        onClick={onAdd}
        className="flex h-[88px] w-full items-center justify-center px-5 py-3"
        aria-label={`Add text with ${font.family}`}
        title={font.family}
      >
        {previewSrc ? (
          <img
            src={previewSrc}
            alt={font.family}
            loading="lazy"
            decoding="async"
            onError={hideBrokenPreview}
            className="max-h-[62px] w-full object-contain"
            draggable={false}
          />
        ) : (
          <span className="truncate text-base font-black text-white/80">
            {font.family}
          </span>
        )}
      </button>

      <button
        type="button"
        onClick={(event) => {
          event.stopPropagation();
          onToggleFavorite();
        }}
        className={`absolute right-2 top-2 flex h-8 w-8 items-center justify-center rounded-xl backdrop-blur-md ${
          favorite
            ? "bg-yellow-300 text-slate-950"
            : "bg-black/25 text-slate-500"
        }`}
        aria-label={
          favorite
            ? `Remove ${font.family} from favorites`
            : `Favorite ${font.family}`
        }
      >
        <Star size={14} fill={favorite ? "currentColor" : "none"} />
      </button>
    </div>
  );
});

export default memo(TextPanel);

function PanelLabel({ title, count }: { title: string; count?: number }) {
  return (
    <div className="flex items-center justify-between gap-3 px-1">
      <h3 className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">
        {title}
      </h3>
      {typeof count === "number" && (
        <span className="text-[10px] font-black text-violet-300">{count}</span>
      )}
    </div>
  );
}