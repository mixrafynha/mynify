"use client";

import { useState, useEffect } from "react";
import { calculateDPI, getQualityLevel, getRecommendedPrintSize } from "../engine/dpi";

export interface DPIInfo {
  dpi: number;
  quality: "excellent" | "good" | "poor";
  recommendedWidthCm: number;
  recommendedHeightCm: number;
}

export function useElementDPI(element: any) {
  const [dpiInfo, setDpiInfo] = useState<DPIInfo | null>(null);

  useEffect(() => {
    // Verifica se é imagem
    if (!element || element.type !== "image") {
      setDpiInfo(null);
      return;
    }

    // Pega as dimensões naturais do meta (já salvas pelo useUpload)
    const naturalWidth = element.meta?.naturalWidth;
    const naturalHeight = element.meta?.naturalHeight;
    const currentWidth = element.width;

    console.log("🔍 useElementDPI Debug:");
    console.log("  - element.type:", element.type);
    console.log("  - element.meta:", element.meta);
    console.log("  - naturalWidth:", naturalWidth);
    console.log("  - naturalHeight:", naturalHeight);
    console.log("  - currentWidth:", currentWidth);

    if (naturalWidth && naturalHeight && currentWidth) {
      const dpi = calculateDPI(naturalWidth, currentWidth);
      const quality = getQualityLevel(dpi);
      const recommended = getRecommendedPrintSize(naturalWidth, naturalHeight);

      console.log("  - DPI calculado:", dpi);
      console.log("  - Qualidade:", quality);

      setDpiInfo({
        dpi,
        quality,
        recommendedWidthCm: Math.round(recommended.widthCm * 10) / 10,
        recommendedHeightCm: Math.round(recommended.heightCm * 10) / 10,
      });
    } else {
      console.log("  - Dados insuficientes para calcular DPI");
      setDpiInfo(null);
    }
  }, [element]);

  return dpiInfo;
}