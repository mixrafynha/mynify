export type EditorPanelId = "ai" | "text" | "upload" | "templates" | "icons" | "images" | "assets3d" | "stickers" | "layers";
export const PANELS = [
  { id: "ai", label: "AI", description: "Generate design ideas" },
  { id: "text", label: "Text", description: "Add text and presets" },
  { id: "upload", label: "Upload", description: "Import user images" },
  { id: "templates", label: "Templates", description: "Ready layouts" },
  { id: "icons", label: "Shapes", description: "Shapes, badges and symbols" },
  { id: "images", label: "Images", description: "Optimized image assets" },
  { id: "assets3d", label: "3D Assets", description: "Light SVG 3D-style assets" },
  { id: "stickers", label: "Stickers", description: "Emoji and graphic stickers" },
  { id: "layers", label: "Layers", description: "Layer order and visibility" },
] as const;
