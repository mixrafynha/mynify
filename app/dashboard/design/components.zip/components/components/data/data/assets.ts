
export type SvgAssetPreset = {
  id: string;
  label: string;
  category: string;
  tags: string[];
  width: number;
  height: number;
  dpi: number;
  svg: string;
  background: string;
};

function esc(v: string) {
  return String(v).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m] || m));
}

export function svgToDataUrl(svg: string) {
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

function textLines(text: string, color: string) {
  return text.split("\\n").map((line, i, arr) => {
    const y = 980 + (i - (arr.length - 1) / 2) * 300;
    return `<text x="1200" y="${y}" text-anchor="middle" font-size="${arr.length > 2 ? 210 : 280}" font-weight="1000" font-family="Arial Black, Impact, sans-serif" fill="${color}" letter-spacing="-8" paint-order="stroke" stroke="#fff" stroke-width="26" stroke-linejoin="round">${esc(line)}</text>`;
  }).join("");
}

function art(type: string, label: string, text: string, color: string) {
  const c = color;
  const dark = "#111827";
  const white = "#ffffff";
  const blue = "#2563eb";
  const red = "#ef4444";
  const yellow = "#facc15";
  const green = "#22c55e";
  const orange = "#f97316";
  const purple = "#7c3aed";
  const common = `filter="url(#shadow)"`;
  const badgeText = text ? `<text x="1200" y="1250" text-anchor="middle" font-size="240" font-weight="1000" font-family="Arial Black, Impact" fill="${white}">${esc(text.replace(/\\n/g, " "))}</text>` : "";

  const map: Record<string, string> = {
    text: textLines(text || label, c),
    heart: `<path ${common} d="M1200 1760C745 1410 520 1160 520 860c0-205 150-360 350-360 145 0 260 76 330 190 70-114 185-190 330-190 200 0 350 155 350 360 0 300-225 550-680 900z" fill="${c}"/>${badgeText}`,
    brokenheart: `<path ${common} d="M1200 1760C745 1410 520 1160 520 860c0-205 150-360 350-360 145 0 260 76 330 190 70-114 185-190 330-190 200 0 350 155 350 360 0 300-225 550-680 900z" fill="${c}"/><path d="M1160 610l-110 360 220 60-160 360 290-470-230-60 120-250z" fill="#fff" opacity=".96"/>`,
    sparkles: `<path ${common} d="M1180 330l130 360 360 130-360 130-130 360-130-360-360-130 360-130z" fill="${c}"/><path d="M1710 1250l70 190 190 70-190 70-70 190-70-190-190-70 190-70zM700 1340l55 150 150 55-150 55-55 150-55-150-150-55 150-55z" fill="${c}" opacity=".85"/>`,
    sunwave: `<circle ${common} cx="980" cy="900" r="300" fill="${yellow}"/><path d="M160 1430c280-200 520-200 800 0s520 200 800 0 420-200 600 0v420H160z" fill="#38bdf8"/><path d="M490 1430c190-100 350-100 540 0s350 100 540 0" fill="none" stroke="#fff" stroke-width="70" stroke-linecap="round" opacity=".8"/>`,
    palm: `<circle cx="1500" cy="720" r="250" fill="${yellow}"/><path ${common} d="M940 1760c140-380 150-730 40-1050" fill="none" stroke="#92400e" stroke-width="100" stroke-linecap="round"/><path d="M970 720c-280-140-500-110-700 80 300-20 520 30 700 190 0-260 120-450 360-580-230 260-300 480-210 680 180-230 390-320 650-270-270 100-450 250-540 450 250-90 480-70 690 60-310 20-560 110-750 280" fill="${green}" stroke="#166534" stroke-width="35" stroke-linejoin="round"/>`,
    trophy: `<path ${common} d="M820 520h760v260c0 300-160 520-380 560-220-40-380-260-380-560z" fill="${c}"/><path d="M820 660H580c0 230 120 390 290 430M1580 660h240c0 230-120 390-290 430" fill="none" stroke="${c}" stroke-width="110" stroke-linecap="round"/><path d="M1200 1340v260M960 1700h480" stroke="${c}" stroke-width="120" stroke-linecap="round"/>`,
    badge: `<circle ${common} cx="1200" cy="1120" r="560" fill="${c}"/><circle cx="1200" cy="1120" r="430" fill="none" stroke="#fff" stroke-width="50" opacity=".9"/>${badgeText}`,
    bottle: `<path ${common} d="M1030 430h340v300l130 180v880c0 110-90 200-200 200h-200c-110 0-200-90-200-200V910l130-180z" fill="${c}"/><rect x="940" y="970" width="520" height="520" rx="60" fill="#fff"/><text x="1200" y="1295" text-anchor="middle" font-size="170" font-weight="1000" font-family="Arial Black" fill="${c}">DAD</text>`,
    bikini: `<path ${common} d="M720 780c200 40 320 170 360 390-230 35-410-20-540-170zM1680 780c-200 40-320 170-360 390 230 35 410-20 540-170z" fill="${c}"/><path d="M1080 1170c90 120 150 250 120 420-30-170 30-300 120-420" fill="none" stroke="${c}" stroke-width="70" stroke-linecap="round"/><path d="M930 780c90-200 180-260 270-180 90-80 180-20 270 180" fill="none" stroke="${c}" stroke-width="50" stroke-linecap="round"/>`,
    flipflops: `<path ${common} d="M760 600c240 0 370 240 320 590-30 210-140 610-330 610-220 0-290-440-250-770 30-260 110-430 260-430z" fill="${green}"/><path d="M1510 600c240 0 370 240 320 590-30 210-140 610-330 610-220 0-290-440-250-770 30-260 110-430 260-430z" fill="${yellow}"/><path d="M720 820l180 250 120-250M1470 820l180 250 120-250" fill="none" stroke="#fff" stroke-width="55" stroke-linecap="round"/>`,
    snorkel: `<circle ${common} cx="1120" cy="1040" r="420" fill="#38bdf8"/><rect x="760" y="850" width="720" height="300" rx="130" fill="#fff"/><circle cx="950" cy="1000" r="90" fill="#60a5fa"/><circle cx="1290" cy="1000" r="90" fill="#60a5fa"/><path d="M1510 900c190 0 220-240 70-310" fill="none" stroke="${orange}" stroke-width="85" stroke-linecap="round"/><path d="M850 1360c180 120 370 120 560 0" fill="none" stroke="#111827" stroke-width="55" stroke-linecap="round"/>`,
    cactus: `<path ${common} d="M1110 1780V760c0-150 90-250 210-250s210 100 210 250v160c120-30 210 40 210 170v210h-180v-190c0-55-30-85-75-85s-75 30-75 85v670zM920 1220v-180c0-55-30-85-75-85s-75 30-75 85v230H590v-250c0-130 90-220 210-190V760c0-150 90-250 210-250" fill="${green}"/>`,
    wave: `<path ${common} d="M390 1430c250-430 620-660 980-580 300 70 520 310 600 650-250-230-520-220-760 20-260 260-550 300-820-90z" fill="#0ea5e9"/><path d="M1330 980c250 80 390 270 410 520-160-150-350-170-540-50 120-180 160-330 130-470z" fill="#fff" opacity=".9"/>`,
    coconut: `<circle ${common} cx="1180" cy="1200" r="430" fill="#92400e"/><path d="M760 1040h850c-40 430-210 690-430 690s-380-260-420-690z" fill="#b45309"/><path d="M980 780l420-340" stroke="${green}" stroke-width="70" stroke-linecap="round"/><path d="M1280 820l230-360" stroke="${orange}" stroke-width="55" stroke-linecap="round"/><circle cx="1030" cy="1020" r="35" fill="#451a03"/><circle cx="1180" cy="990" r="35" fill="#451a03"/>`,
    torch: `<path ${common} d="M1120 880c-160-220 90-360 40-560 260 190 390 360 180 610 130-40 230-110 300-220 40 260-120 470-440 470-230 0-390-100-440-290 110 70 230 90 360-10z" fill="${red}"/><path d="M1040 1170h320l-80 680h-160z" fill="#111827"/><path d="M930 1850h540" stroke="#111827" stroke-width="90" stroke-linecap="round"/>`,
    hands: `<path ${common} d="M620 960c220-160 420-110 580 150 160-260 360-310 580-150-40 350-230 580-580 720-350-140-540-370-580-720z" fill="${blue}"/><path d="M1200 1120l130 160 190-260" fill="none" stroke="#fff" stroke-width="70" stroke-linecap="round" stroke-linejoin="round"/><path d="M620 960l-220-110M1780 960l220-110" stroke="${red}" stroke-width="75" stroke-linecap="round"/>`,
    stars: `<path ${common} d="M760 540l90 220 240 20-180 155 55 235-205-125-205 125 55-235-180-155 240-20zM1540 900l70 170 185 15-140 120 42 180-157-95-157 95 42-180-140-120 185-15zM1080 1460l55 135 145 12-110 95 33 143-123-75-123 75 33-143-110-95 145-12z" fill="${c}"/>`,
    hat: `<path ${common} d="M760 720h880l120 680H640z" fill="${red}"/><path d="M520 1400h1360" stroke="${blue}" stroke-width="130" stroke-linecap="round"/><path d="M910 720c60-190 140-280 290-280s230 90 290 280" fill="none" stroke="#fff" stroke-width="90"/>`,
    eagle: `<path ${common} d="M420 1070c320-130 560-120 780 20 220-140 460-150 780-20-270 120-450 280-560 520-130-140-220-280-220-500 0 220-90 360-220 500-110-240-290-400-560-520z" fill="${blue}"/><path d="M1120 800l80-180 80 180 190 30-135 130 35 190-170-90-170 90 35-190-135-130z" fill="${red}"/>`,
    skull: `<path ${common} d="M1200 460c370 0 620 260 620 600 0 240-120 390-300 480v260H880v-260c-180-90-300-240-300-480 0-340 250-600 620-600z" fill="${dark}"/><circle cx="980" cy="1060" r="120" fill="#fff"/><circle cx="1420" cy="1060" r="120" fill="#fff"/><path d="M1200 1180l-95 170h190z" fill="#fff"/><path d="M930 1640h540" stroke="#fff" stroke-width="70" stroke-linecap="round" stroke-dasharray="80 80"/>`,
    wings: `<path ${common} d="M1120 1200C780 820 520 760 260 900c260 40 390 150 490 340-180-60-340-30-480 80 260 0 470 110 650 330 80-160 140-300 200-450zM1280 1200c340-380 600-440 860-300-260 40-390 150-490 340 180-60 340-30 480 80-260 0-470 110-650 330-80-160-140-300-200-450z" fill="${dark}"/>`,
    star: `<path ${common} d="M1200 350l210 520 560 45-430 360 135 545-475-290-475 290 135-545-430-360 560-45z" fill="${c}"/>`,
    snake: `<path ${common} d="M820 620c420-260 920 60 700 410-120 190-470 120-500 320-25 170 260 250 520 120" fill="none" stroke="${c}" stroke-width="130" stroke-linecap="round"/><circle cx="1460" cy="700" r="45" fill="#fff"/><path d="M1540 540l180-110" stroke="${red}" stroke-width="35" stroke-linecap="round"/>`,
    flame: `<path ${common} d="M1190 1970c-330-170-470-410-420-720 40-250 210-390 260-650 230 160 340 350 320 570 130-90 200-220 210-390 220 220 310 480 230 740-90 300-310 450-600 450z" fill="${orange}"/><path d="M1190 1780c-150-100-210-230-160-390 25-80 90-150 120-270 120 90 180 210 150 360 90-50 140-120 160-210 120 160 100 390-270 510z" fill="${yellow}"/>`,
    bolt: `<path ${common} d="M1300 300L640 1260h430l-170 840 760-1080h-440z" fill="${c}"/>`,
    barbell: `<path ${common} d="M520 980h160v440H520zM760 860h180v680H760zM1460 860h180v680h-180zM1720 980h160v440h-160zM880 1120h640v160H880z" fill="${dark}"/>`,
    boxing: `<path ${common} d="M760 650h360c170 0 300 130 300 300v340H830c-180 0-330-150-330-330V910c0-145 115-260 260-260z" fill="${red}"/><path d="M1090 1280v330H680v-330" fill="${red}"/><path d="M1440 980h230c120 0 220 100 220 220v170h-450z" fill="${red}" opacity=".9"/>`,
    ball: `<circle ${common} cx="1200" cy="1200" r="620" fill="${orange}"/><path d="M580 1200h1240M1200 580c-210 250-210 990 0 1240M1200 580c210 250 210 990 0 1240M780 780c270 220 570 220 840 0M780 1620c270-220 570-220 840 0" fill="none" stroke="#111827" stroke-width="55"/>`,
    runner: `<circle cx="1180" cy="520" r="130" fill="${dark}"/><path ${common} d="M1080 740l360 220-210 320 340 330-150 150-440-410 190-300-280-170z" fill="${dark}"/><path d="M1010 1000l-330 180M1060 1390l-310 350" stroke="${dark}" stroke-width="110" stroke-linecap="round"/>`,
    crown: `<path ${common} d="M520 1600l150-780 350 340 180-560 180 560 350-340 150 780z" fill="${c}"/><rect x="600" y="1570" width="1200" height="180" rx="60" fill="${c}"/>`,
    diamond: `<path ${common} d="M720 560h960l300 390-780 900-780-900z" fill="${c}"/><path d="M720 560l480 1290 480-1290M420 950h1560M960 560l-180 390 420 900 420-900-180-390" fill="none" stroke="#fff" stroke-width="45" opacity=".75"/>`,
    laurel: `<path ${common} d="M880 1680c-260-240-360-600-220-960M1520 1680c260-240 360-600 220-960" fill="none" stroke="${c}" stroke-width="70" stroke-linecap="round"/><path d="M720 820c-170 60-250 150-250 280 160-30 250-120 250-280zM1680 820c170 60 250 150 250 280-160-30-250-120-250-280zM810 1160c-180 40-280 130-300 260 170-10 280-90 300-260zM1590 1160c180 40 280 130 300 260-170-10-280-90-300-260z" fill="${c}"/>`,
    circlemark: `<circle ${common} cx="1200" cy="1200" r="520" fill="none" stroke="${dark}" stroke-width="120"/><circle cx="1200" cy="1200" r="170" fill="${dark}"/>`,
    gamepad: `<path ${common} d="M720 900h960c220 0 390 180 390 400 0 250-170 440-370 440-160 0-220-120-300-220h-400c-80 100-140 220-300 220-200 0-370-190-370-440 0-220 170-400 390-400z" fill="${purple}"/><path d="M780 1260h310M935 1105v310" stroke="#fff" stroke-width="70" stroke-linecap="round"/><circle cx="1510" cy="1180" r="70" fill="#fff"/><circle cx="1690" cy="1340" r="70" fill="#fff"/>`,
    pixelheart: `<path ${common} d="M650 650h350v180h200V650h350v180h180v520h-180v180h-180v180h-170v180h-200v-180H830v-180H650v-180H470V830h180z" fill="${red}"/>`,
    alien: `<path ${common} d="M1200 520c390 0 650 240 650 590 0 380-320 690-650 690s-650-310-650-690c0-350 260-590 650-590z" fill="${green}"/><ellipse cx="960" cy="1130" rx="150" ry="230" fill="#111827" transform="rotate(-20 960 1130)"/><ellipse cx="1440" cy="1130" rx="150" ry="230" fill="#111827" transform="rotate(20 1440 1130)"/><path d="M980 1510c140 90 300 90 440 0" fill="none" stroke="#111827" stroke-width="55" stroke-linecap="round"/>`,
    rocket: `<path ${common} d="M1210 360c370 280 480 650 300 1080l-300-90-300 90c-180-430-70-800 300-1080z" fill="${red}"/><circle cx="1210" cy="780" r="140" fill="#38bdf8" stroke="#fff" stroke-width="45"/><path d="M910 1390l-230 280 360-80M1510 1390l230 280-360-80" fill="${blue}"/><path d="M1210 1460c-110 140-120 270 0 430 120-160 110-290 0-430z" fill="${yellow}"/>`,
    arcade: `<rect ${common} x="700" y="420" width="1000" height="1520" rx="140" fill="${purple}"/><rect x="840" y="600" width="720" height="540" rx="50" fill="#111827"/><circle cx="1000" cy="1400" r="80" fill="${red}"/><circle cx="1210" cy="1400" r="80" fill="${yellow}"/><path d="M1350 1380h220M1460 1270v220" stroke="#fff" stroke-width="55" stroke-linecap="round"/>`,
    rose: `<path ${common} d="M1180 860c150-230 470-150 470 110 0 350-470 470-470 470s-470-120-470-470c0-260 320-340 470-110z" fill="${red}"/><path d="M1180 1440v520" stroke="#166534" stroke-width="70" stroke-linecap="round"/><path d="M1180 1660c-170-120-300-130-430-40 150 110 290 120 430 40zM1180 1780c170-120 300-130 430-40-150 110-290 120-430 40z" fill="${green}"/>`,
    dagger: `<path ${common} d="M1200 300l180 860-180 220-180-220z" fill="#e5e7eb"/><path d="M820 1350h760" stroke="${dark}" stroke-width="100" stroke-linecap="round"/><path d="M1200 1400v470" stroke="${dark}" stroke-width="120" stroke-linecap="round"/>`,
    bird: `<path ${common} d="M500 980c420-250 690-210 960 120 180-80 330-80 500 20-220 70-360 200-450 390-150-140-320-210-520-220-180-10-340-120-490-310z" fill="${dark}"/><path d="M1260 1110c120-260 320-390 600-390-160 200-260 380-300 570" fill="${blue}"/>`,
    heartflame: `<path ${common} d="M1200 1770C850 1480 680 1270 680 1020c0-180 130-320 300-320 100 0 175 50 220 130 45-80 120-130 220-130 170 0 300 140 300 320 0 250-170 460-520 750z" fill="${red}"/><path d="M1210 780c-120-170 70-270 30-420 200 140 270 260 130 430 90-30 150-90 190-170 50 210-70 360-350 360-190 0-300-90-330-240 90 50 190 60 330 40z" fill="${orange}"/>`,
    anchor: `<path ${common} d="M1200 510a170 170 0 100 340 170 170 0 000-340zm0 340v830" stroke="${blue}" stroke-width="110" stroke-linecap="round" fill="none"/><path d="M820 1080h760M620 1380c80 290 260 460 580 500 320-40 500-210 580-500" fill="none" stroke="${blue}" stroke-width="110" stroke-linecap="round"/>`,
    cap: `<path ${common} d="M610 1100c120-310 380-470 780-470 260 0 490 110 700 330-200-40-370-10-520 90-290-70-600-50-960 50z" fill="${dark}"/><path d="M610 1100c250 110 570 130 960-50" fill="none" stroke="#fff" stroke-width="50" opacity=".8"/>${badgeText}`
  };
  return map[type] || map.badge;
}

export function makeRealSvgAsset(label: string, type: string, text: string, color: string, background: string) {
  return `<svg xmlns="http://www.w3.org/2000/svg" width="8192" height="8192" viewBox="0 0 2400 2400" role="img" aria-label="${esc(label)}"><defs><filter id="shadow" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="38" stdDeviation="32" flood-color="#000" flood-opacity=".22"/></filter><radialGradient id="soft" cx="50%" cy="20%" r="80%"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="${background}" stop-opacity="1"/></radialGradient></defs><rect width="2400" height="2400" fill="transparent"/><circle cx="1960" cy="510" r="340" fill="${background}" opacity=".65"/><circle cx="480" cy="1860" r="420" fill="${background}" opacity=".5"/>${art(type, label, text, color)}</svg>`;
}

export const IMAGE_COLLECTIONS = [
  { id: "best-dad-ever", category: "Fathers Day", label: "Best Dad Ever", tags: ["fathers day", "best dad ever", "text"], width: 8192, height: 8192, dpi: 2000, background: "#fff7ed", svg: makeRealSvgAsset("Best Dad Ever", "text", "BEST
DAD
EVER", "#ff5a3d", "#fff7ed") },
  { id: "dad-balloon", category: "Fathers Day", label: "Dad Balloon", tags: ["fathers day", "dad balloon", "heart"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Dad Balloon", "heart", "BEST
DAD", "#ef4444", "#fff1f2") },
  { id: "dad-trophy", category: "Fathers Day", label: "Dad Trophy", tags: ["fathers day", "dad trophy", "trophy"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Dad Trophy", "trophy", "THE
BEST
DAD", "#f59e0b", "#fffbeb") },
  { id: "dad-beer", category: "Fathers Day", label: "Dad Bottle", tags: ["fathers day", "dad bottle", "bottle"], width: 8192, height: 8192, dpi: 2000, background: "#fef3c7", svg: makeRealSvgAsset("Dad Bottle", "bottle", "DAD", "#b45309", "#fef3c7") },
  { id: "gold-sparkles", category: "Fathers Day", label: "Gold Sparkles", tags: ["fathers day", "gold sparkles", "sparkles"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Gold Sparkles", "sparkles", "", "#d6a02a", "#fffbeb") },
  { id: "blue-heart", category: "Fathers Day", label: "Blue Heart", tags: ["fathers day", "blue heart", "heart"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Blue Heart", "heart", "", "#60a5fa", "#eff6ff") },
  { id: "super-dad", category: "Fathers Day", label: "Super Dad", tags: ["fathers day", "super dad", "badge"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Super Dad", "badge", "SUPER
DAD", "#2563eb", "#eff6ff") },
  { id: "dad-cap", category: "Fathers Day", label: "Dad Cap", tags: ["fathers day", "dad cap", "cap"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Dad Cap", "cap", "DAD", "#111827", "#f8fafc") },
  { id: "summer-bikini", category: "Summer Season", label: "Summer Bikini", tags: ["summer season", "summer bikini", "bikini"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Summer Bikini", "bikini", "", "#ff4da6", "#fff1f2") },
  { id: "palm-sun", category: "Summer Season", label: "Palm Sun", tags: ["summer season", "palm sun", "palm"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Palm Sun", "palm", "", "#22c55e", "#f0fdf4") },
  { id: "sun-wave", category: "Summer Season", label: "Sun Wave", tags: ["summer season", "sun wave", "sunwave"], width: 8192, height: 8192, dpi: 2000, background: "#fefce8", svg: makeRealSvgAsset("Sun Wave", "sunwave", "", "#facc15", "#fefce8") },
  { id: "flip-flops", category: "Summer Season", label: "Flip Flops", tags: ["summer season", "flip flops", "flipflops"], width: 8192, height: 8192, dpi: 2000, background: "#ecfdf5", svg: makeRealSvgAsset("Flip Flops", "flipflops", "", "#22c55e", "#ecfdf5") },
  { id: "snorkel", category: "Summer Season", label: "Snorkel Fun", tags: ["summer season", "snorkel fun", "snorkel"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Snorkel Fun", "snorkel", "", "#38bdf8", "#eff6ff") },
  { id: "cactus", category: "Summer Season", label: "Summer Cactus", tags: ["summer season", "summer cactus", "cactus"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Summer Cactus", "cactus", "", "#16a34a", "#f0fdf4") },
  { id: "wave", category: "Summer Season", label: "Ocean Wave", tags: ["summer season", "ocean wave", "wave"], width: 8192, height: 8192, dpi: 2000, background: "#f0f9ff", svg: makeRealSvgAsset("Ocean Wave", "wave", "", "#0ea5e9", "#f0f9ff") },
  { id: "coconut", category: "Summer Season", label: "Coconut Drink", tags: ["summer season", "coconut drink", "coconut"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Coconut Drink", "coconut", "", "#92400e", "#fffbeb") },
  { id: "stars-stripes", category: "4th of July", label: "Stars Stripes", tags: ["4th of july", "stars stripes", "text"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Stars Stripes", "text", "STARS
STRIPES
FREEDOM", "#1d4ed8", "#eff6ff") },
  { id: "liberty", category: "4th of July", label: "Liberty Torch", tags: ["4th of july", "liberty torch", "torch"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Liberty Torch", "torch", "", "#dc2626", "#fff1f2") },
  { id: "usa-hands", category: "4th of July", label: "USA Hands", tags: ["4th of july", "usa hands", "hands"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("USA Hands", "hands", "", "#2563eb", "#eff6ff") },
  { id: "freedom-squad", category: "4th of July", label: "Freedom Squad", tags: ["4th of july", "freedom squad", "text"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Freedom Squad", "text", "FREEDOM
SQUAD", "#2563eb", "#eff6ff") },
  { id: "uncle-hat", category: "4th of July", label: "Uncle Hat", tags: ["4th of july", "uncle hat", "hat"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Uncle Hat", "hat", "", "#dc2626", "#fff1f2") },
  { id: "stars", category: "4th of July", label: "Patriot Stars", tags: ["4th of july", "patriot stars", "stars"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Patriot Stars", "stars", "", "#ef4444", "#f8fafc") },
  { id: "eagle", category: "4th of July", label: "Freedom Eagle", tags: ["4th of july", "freedom eagle", "eagle"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Freedom Eagle", "eagle", "", "#1e40af", "#eff6ff") },
  { id: "usa-badge", category: "4th of July", label: "USA Badge", tags: ["4th of july", "usa badge", "badge"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("USA Badge", "badge", "USA", "#1d4ed8", "#eff6ff") },
  { id: "skull-rose", category: "Streetwear", label: "Skull Rose", tags: ["streetwear", "skull rose", "skull"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Skull Rose", "skull", "", "#111827", "#f8fafc") },
  { id: "broken-heart", category: "Streetwear", label: "Broken Heart", tags: ["streetwear", "broken heart", "brokenheart"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Broken Heart", "brokenheart", "", "#ef4444", "#fff1f2") },
  { id: "urban-wings", category: "Streetwear", label: "Urban Wings", tags: ["streetwear", "urban wings", "wings"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Urban Wings", "wings", "", "#111827", "#f8fafc") },
  { id: "graffiti-star", category: "Streetwear", label: "Graffiti Star", tags: ["streetwear", "graffiti star", "star"], width: 8192, height: 8192, dpi: 2000, background: "#faf5ff", svg: makeRealSvgAsset("Graffiti Star", "star", "", "#a855f7", "#faf5ff") },
  { id: "no-fear", category: "Streetwear", label: "No Fear", tags: ["streetwear", "no fear", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("No Fear", "text", "NO
FEAR", "#111827", "#f8fafc") },
  { id: "snake", category: "Streetwear", label: "Snake", tags: ["streetwear", "snake", "snake"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Snake", "snake", "", "#16a34a", "#f0fdf4") },
  { id: "flames", category: "Streetwear", label: "Flames", tags: ["streetwear", "flames", "flame"], width: 8192, height: 8192, dpi: 2000, background: "#fff7ed", svg: makeRealSvgAsset("Flames", "flame", "", "#f97316", "#fff7ed") },
  { id: "thunder", category: "Streetwear", label: "Thunder", tags: ["streetwear", "thunder", "bolt"], width: 8192, height: 8192, dpi: 2000, background: "#fefce8", svg: makeRealSvgAsset("Thunder", "bolt", "", "#facc15", "#fefce8") },
  { id: "beast-mode", category: "Gym & Sport", label: "Beast Mode", tags: ["gym & sport", "beast mode", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Beast Mode", "text", "BEAST
MODE", "#111827", "#f8fafc") },
  { id: "barbell", category: "Gym & Sport", label: "Barbell", tags: ["gym & sport", "barbell", "barbell"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Barbell", "barbell", "", "#334155", "#f8fafc") },
  { id: "boxing", category: "Gym & Sport", label: "Boxing Gloves", tags: ["gym & sport", "boxing gloves", "boxing"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Boxing Gloves", "boxing", "", "#dc2626", "#fff1f2") },
  { id: "basketball", category: "Gym & Sport", label: "Basketball", tags: ["gym & sport", "basketball", "ball"], width: 8192, height: 8192, dpi: 2000, background: "#fff7ed", svg: makeRealSvgAsset("Basketball", "ball", "", "#f97316", "#fff7ed") },
  { id: "runner", category: "Gym & Sport", label: "Runner", tags: ["gym & sport", "runner", "runner"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Runner", "runner", "", "#0f172a", "#f8fafc") },
  { id: "trophy", category: "Gym & Sport", label: "Champion Trophy", tags: ["gym & sport", "champion trophy", "trophy"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Champion Trophy", "trophy", "", "#f59e0b", "#fffbeb") },
  { id: "sport-lightning", category: "Gym & Sport", label: "Sport Lightning", tags: ["gym & sport", "sport lightning", "bolt"], width: 8192, height: 8192, dpi: 2000, background: "#fefce8", svg: makeRealSvgAsset("Sport Lightning", "bolt", "", "#facc15", "#fefce8") },
  { id: "gym-badge", category: "Gym & Sport", label: "Gym Badge", tags: ["gym & sport", "gym badge", "badge"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Gym Badge", "badge", "GYM", "#111827", "#f8fafc") },
  { id: "crown", category: "Luxury Logos", label: "Gold Crown", tags: ["luxury logos", "gold crown", "crown"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Gold Crown", "crown", "", "#d4af37", "#fffbeb") },
  { id: "diamond", category: "Luxury Logos", label: "Diamond", tags: ["luxury logos", "diamond", "diamond"], width: 8192, height: 8192, dpi: 2000, background: "#f0f9ff", svg: makeRealSvgAsset("Diamond", "diamond", "", "#38bdf8", "#f0f9ff") },
  { id: "monogram", category: "Luxury Logos", label: "Monogram", tags: ["luxury logos", "monogram", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Monogram", "text", "LUXE", "#111827", "#f8fafc") },
  { id: "laurel", category: "Luxury Logos", label: "Laurel", tags: ["luxury logos", "laurel", "laurel"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Laurel", "laurel", "", "#b45309", "#fffbeb") },
  { id: "elegant-script", category: "Luxury Logos", label: "Elegant Script", tags: ["luxury logos", "elegant script", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Elegant Script", "text", "Maison", "#111827", "#f8fafc") },
  { id: "royal-badge", category: "Luxury Logos", label: "Royal Badge", tags: ["luxury logos", "royal badge", "badge"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Royal Badge", "badge", "ROYAL", "#d4af37", "#fffbeb") },
  { id: "minimal-mark", category: "Luxury Logos", label: "Minimal Mark", tags: ["luxury logos", "minimal mark", "circlemark"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Minimal Mark", "circlemark", "", "#111827", "#f8fafc") },
  { id: "gold-star", category: "Luxury Logos", label: "Gold Star", tags: ["luxury logos", "gold star", "star"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Gold Star", "star", "", "#d4af37", "#fffbeb") },
  { id: "gamepad", category: "Gaming", label: "Gamepad", tags: ["gaming", "gamepad", "gamepad"], width: 8192, height: 8192, dpi: 2000, background: "#f5f3ff", svg: makeRealSvgAsset("Gamepad", "gamepad", "", "#7c3aed", "#f5f3ff") },
  { id: "pixel-heart", category: "Gaming", label: "Pixel Heart", tags: ["gaming", "pixel heart", "pixelheart"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Pixel Heart", "pixelheart", "", "#ef4444", "#fff1f2") },
  { id: "level-up", category: "Gaming", label: "Level Up", tags: ["gaming", "level up", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Level Up", "text", "LEVEL
UP", "#22c55e", "#f0fdf4") },
  { id: "alien", category: "Gaming", label: "Alien", tags: ["gaming", "alien", "alien"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Alien", "alien", "", "#22c55e", "#f0fdf4") },
  { id: "rocket", category: "Gaming", label: "Rocket", tags: ["gaming", "rocket", "rocket"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Rocket", "rocket", "", "#ef4444", "#fff1f2") },
  { id: "arcade", category: "Gaming", label: "Arcade", tags: ["gaming", "arcade", "arcade"], width: 8192, height: 8192, dpi: 2000, background: "#f5f3ff", svg: makeRealSvgAsset("Arcade", "arcade", "", "#7c3aed", "#f5f3ff") },
  { id: "controller-bolt", category: "Gaming", label: "Controller Bolt", tags: ["gaming", "controller bolt", "bolt"], width: 8192, height: 8192, dpi: 2000, background: "#fefce8", svg: makeRealSvgAsset("Controller Bolt", "bolt", "", "#facc15", "#fefce8") },
  { id: "gg-badge", category: "Gaming", label: "GG Badge", tags: ["gaming", "gg badge", "badge"], width: 8192, height: 8192, dpi: 2000, background: "#f5f3ff", svg: makeRealSvgAsset("GG Badge", "badge", "GG", "#7c3aed", "#f5f3ff") },
  { id: "tattoo-rose", category: "Tattoo", label: "Tattoo Rose", tags: ["tattoo", "tattoo rose", "rose"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Tattoo Rose", "rose", "", "#be123c", "#fff1f2") },
  { id: "dagger", category: "Tattoo", label: "Dagger", tags: ["tattoo", "dagger", "dagger"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Dagger", "dagger", "", "#334155", "#f8fafc") },
  { id: "swallow", category: "Tattoo", label: "Swallow", tags: ["tattoo", "swallow", "bird"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Swallow", "bird", "", "#0f172a", "#f8fafc") },
  { id: "sacred-heart", category: "Tattoo", label: "Sacred Heart", tags: ["tattoo", "sacred heart", "heartflame"], width: 8192, height: 8192, dpi: 2000, background: "#fff1f2", svg: makeRealSvgAsset("Sacred Heart", "heartflame", "", "#dc2626", "#fff1f2") },
  { id: "snake-tattoo", category: "Tattoo", label: "Snake Tattoo", tags: ["tattoo", "snake tattoo", "snake"], width: 8192, height: 8192, dpi: 2000, background: "#f0fdf4", svg: makeRealSvgAsset("Snake Tattoo", "snake", "", "#166534", "#f0fdf4") },
  { id: "oldschool-star", category: "Tattoo", label: "Oldschool Star", tags: ["tattoo", "oldschool star", "star"], width: 8192, height: 8192, dpi: 2000, background: "#fffbeb", svg: makeRealSvgAsset("Oldschool Star", "star", "", "#f59e0b", "#fffbeb") },
  { id: "anchor", category: "Tattoo", label: "Anchor", tags: ["tattoo", "anchor", "anchor"], width: 8192, height: 8192, dpi: 2000, background: "#eff6ff", svg: makeRealSvgAsset("Anchor", "anchor", "", "#1d4ed8", "#eff6ff") },
  { id: "tattoo-letter", category: "Tattoo", label: "Tattoo Letter", tags: ["tattoo", "tattoo letter", "text"], width: 8192, height: 8192, dpi: 2000, background: "#f8fafc", svg: makeRealSvgAsset("Tattoo Letter", "text", "BORN
FREE", "#111827", "#f8fafc") },
] as const satisfies SvgAssetPreset[];

export const IMAGE_TEMPLATES: SvgAssetPreset[] = [...IMAGE_COLLECTIONS];
export const IMAGE_CATEGORIES = Array.from(new Set(IMAGE_COLLECTIONS.map((item) => item.category)));
