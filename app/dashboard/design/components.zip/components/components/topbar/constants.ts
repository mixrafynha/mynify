export const ZOOM_MIN = 25;
export const ZOOM_MAX = 400;
export const ZOOM_STEP = 25;
export const ZOOM_PRESETS = [75, 100, 125, 150, 200, 300] as const;

export function clampZoom(value: number) {
  return Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(value || 100)));
}

export const iconButtonClass =
  "group relative flex h-7 w-7 shrink-0 touch-manipulation items-center justify-center overflow-hidden rounded-lg border border-white/[0.08] bg-white/[0.055] text-white/76 shadow-[inset_0_1px_0_rgba(255,255,255,0.08),0_6px_14px_rgba(0,0,0,0.20)] transition duration-150 hover:border-white/16 hover:bg-white/[0.10] hover:text-white active:scale-[0.94] disabled:pointer-events-none disabled:opacity-35 sm:h-8 sm:w-8 sm:rounded-xl md:h-9 md:w-9 md:rounded-xl";
