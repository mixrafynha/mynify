export type EditorSide = "front" | "back";

export interface TopBarProps {
  productId?: string;
  side: EditorSide;
  setSide: (side: EditorSide) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  zoom?: number;
  onZoomChange?: (zoom: number) => void;
  onSaveDesign: () => Promise<void> | void;
  onPreviewDesign: () => Promise<void> | void;
  onUndo?: () => void;
  onRedo?: () => void;
  saving?: boolean;
  elements: any[];
  mockupColor?: string;
}

export interface PreviewPayloadInput {
  productId?: string;
  side: EditorSide;
  elements: any[];
  mockupColor: string;
}
