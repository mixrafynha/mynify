import type { PreviewPayloadInput } from "../types";

const NATURAL_WIDTH = 1024;
const NATURAL_HEIGHT = 1024;

async function captureDesignImage() {
  if (typeof window === "undefined") return null;

  const designNode = document.getElementById("design-safe-area");
  const canvasContainer = document.getElementById("mockup-export-root");
  if (!designNode || !canvasContainer) return null;

  const { toPng } = await import("html-to-image");
  const canvasRect = canvasContainer.getBoundingClientRect();

  const scaleX = canvasRect.width > 0 ? NATURAL_WIDTH / canvasRect.width : 1;
  const scaleY = canvasRect.height > 0 ? NATURAL_HEIGHT / canvasRect.height : 1;
  const cloneNode = designNode.cloneNode(true) as HTMLElement;

  cloneNode.style.position = "absolute";
  cloneNode.style.top = "0";
  cloneNode.style.left = "0";
  cloneNode.style.width = `${NATURAL_WIDTH}px`;
  cloneNode.style.height = `${NATURAL_HEIGHT}px`;
  cloneNode.style.transform = "none";
  cloneNode.style.margin = "0";
  cloneNode.style.padding = "0";
  cloneNode.style.backgroundColor = "transparent";

  cloneNode.querySelectorAll<HTMLElement>("[style*='position: absolute'], .absolute").forEach((child) => {
    const left = Number.parseFloat(child.style.left);
    const top = Number.parseFloat(child.style.top);
    const width = Number.parseFloat(child.style.width);
    const height = Number.parseFloat(child.style.height);
    const fontSize = Number.parseFloat(child.style.fontSize);

    if (Number.isFinite(left)) child.style.left = `${left * scaleX}px`;
    if (Number.isFinite(top)) child.style.top = `${top * scaleY}px`;
    if (Number.isFinite(width)) child.style.width = `${width * scaleX}px`;
    if (Number.isFinite(height)) child.style.height = `${height * scaleY}px`;
    if (Number.isFinite(fontSize)) child.style.fontSize = `${fontSize * scaleY}px`;

    child.style.transform = "none";
    child.style.transformOrigin = "top left";
  });

  const tempContainer = document.createElement("div");
  tempContainer.style.position = "fixed";
  tempContainer.style.top = "-10000px";
  tempContainer.style.left = "-10000px";
  tempContainer.style.width = `${NATURAL_WIDTH}px`;
  tempContainer.style.height = `${NATURAL_HEIGHT}px`;
  tempContainer.style.pointerEvents = "none";
  tempContainer.style.backgroundColor = "transparent";
  tempContainer.appendChild(cloneNode);

  document.body.appendChild(tempContainer);
  try {
    return await toPng(cloneNode, {
      cacheBust: true,
      pixelRatio: 2,
      backgroundColor: "transparent",
      width: NATURAL_WIDTH,
      height: NATURAL_HEIGHT,
      filter: (node) => {
        const element = node as HTMLElement;
        return !element.classList?.contains("no-export");
      },
    });
  } finally {
    tempContainer.remove();
  }
}

export async function storePreviewPayload(input: PreviewPayloadInput) {
  if (typeof window === "undefined" || !input.productId) return;

  const designImage = await captureDesignImage();
  const printBox = (window as any).__MYNIFY_PRINT_BOX__ ?? null;
  const payload = JSON.stringify({
    ...input,
    designImage,
    printBox,
    safeArea: printBox,
    generateMockupAI: false,
    updatedAt: Date.now(),
  });

  const key = `mynify-editor-preview:${input.productId}`;
  localStorage.setItem(key, payload);
  sessionStorage.setItem(key, payload);
}
