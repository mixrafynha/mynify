"use client";

import { memo } from "react";

function BrandSection() {
  return (
    <div className="flex min-w-0 shrink-0 items-center">
      <div
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border border-white/[0.10] bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-400 text-[10px] font-black leading-none text-white shadow-[0_8px_20px_rgba(168,85,247,.24)] sm:h-8 sm:w-8 sm:rounded-xl sm:text-[12px]"
        aria-label="Mynify editor"
        title="Mynify"
      >
        M
      </div>

      <h1
        className="ml-2 hidden select-none whitespace-nowrap text-[20px] font-black uppercase leading-none tracking-[-0.055em] text-white xl:block"
        style={{ fontFamily: "Sibarico, var(--font-sibarico), ui-serif, Georgia, serif" }}
      >
        <span>MY</span>
        <span className="bg-gradient-to-r from-violet-200 via-fuchsia-300 to-cyan-200 bg-clip-text text-transparent">
          NIFY
        </span>
      </h1>
    </div>
  );
}

export default memo(BrandSection);
