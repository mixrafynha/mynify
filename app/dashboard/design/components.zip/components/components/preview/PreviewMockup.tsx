"use client";

import { memo, useMemo } from "react";
import { CheckCircle2, Sparkles } from "lucide-react";
import { MOCKUP_AREA } from "../canvas/constants";
import { MOCKUP_VISUAL_SCALE_BY_PRODUCT } from "../canvas/productConfig";
import PreviewCleanElement from "./PreviewCleanElement";
import type { PreviewSideData } from "./types/preview";

function isDarkColor(color: string) {
  const value = String(color || "#ffffff").replace("#", "");
  if (value.length < 6) return false;

  const r = parseInt(value.slice(0, 2), 16);
  const g = parseInt(value.slice(2, 4), 16);
  const b = parseInt(value.slice(4, 6), 16);

  return r * 0.299 + g * 0.587 + b * 0.114 < 120;
}

function PreviewMockup({
  data,
  productId,
  color,
  generatedMockupUrl,
}: {
  data: PreviewSideData;
  productId: string;
  color: string;
  generatedMockupUrl?: string | null;
}) {
  const sorted = useMemo(
    () => [...data.elements].sort((a, b) => Number(a.zIndex || 0) - Number(b.zIndex || 0)),
    [data.elements],
  );

  const visualScale = MOCKUP_VISUAL_SCALE_BY_PRODUCT?.[productId]?.[data.side] ?? 1;
  const dark = isDarkColor(color);
  const hasAiMockup = Boolean(generatedMockupUrl);

  return (
    <section className="relative min-h-[calc(94dvh-182px)] overflow-hidden rounded-[20px] border border-white/10 bg-[#101018] p-2 shadow-[inset_0_1px_0_rgba(255,255,255,.08)] sm:min-h-[620px] sm:rounded-[34px] sm:p-5 xl:min-h-[760px]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_48%_10%,rgba(255,255,255,.12),transparent_28%),radial-gradient(circle_at_18%_20%,rgba(168,85,247,.20),transparent_30%),radial-gradient(circle_at_84%_70%,rgba(34,211,238,.15),transparent_34%),linear-gradient(180deg,#151522,#070711)]" />
      <div className="absolute inset-x-6 bottom-6 h-20 rounded-[100%] bg-black/45 blur-3xl" />

      <div className="relative z-10 flex h-full min-h-[inherit] flex-col">
        <div className="mb-2 flex items-center justify-between gap-2 px-1 sm:mb-4">
          <div className="min-w-0">
            <p className="truncate text-[8px] font-black uppercase tracking-[.18em] text-white/36 sm:text-[10px]">
              Production mockup
            </p>
            <h3 className="mt-0.5 truncate text-base font-black tracking-[-.05em] text-white sm:text-3xl">
              {hasAiMockup ? "AI on-model preview" : "On-model preview"}
            </h3>
          </div>

          <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-emerald-300/15 bg-emerald-300/10 px-2 py-1 text-[9px] font-black text-emerald-100 sm:px-3 sm:py-1.5 sm:text-[11px]">
            {hasAiMockup ? <Sparkles size={12} /> : <CheckCircle2 size={12} />}
            {hasAiMockup ? "AI" : "Clean"}
          </span>
        </div>

        <div
          className="relative flex flex-1 items-center justify-center overflow-hidden rounded-[18px] border border-white/10 bg-[linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.025))] px-1 py-2 sm:rounded-[30px] sm:px-8 sm:py-8"
          data-production-preview-root
        >
          <div className="absolute left-1/2 top-[9%] h-[78%] w-[54%] -translate-x-1/2 rounded-full bg-white/[.035] blur-2xl" />

          <div className="relative mx-auto flex w-full max-w-[780px] items-end justify-center">
            {!hasAiMockup && (
              <>
                <div className="absolute top-[1%] h-[16%] w-[18%] rounded-full bg-[#d8c2ad] shadow-[inset_0_-18px_30px_rgba(0,0,0,.16)]" />
                <div className="absolute top-[14%] h-[10%] w-[8%] rounded-b-[40%] bg-[#c9aa92]" />
                <div className="absolute top-[6%] h-[9%] w-[21%] rounded-t-full bg-[#2b211d]" />
                <div className="absolute top-[25%] h-[58%] w-[54%] rounded-[48%_48%_26%_26%] bg-black/18 blur-xl" />
                <div className="absolute top-[25%] h-[54%] w-[70%] rounded-[42%] bg-[linear-gradient(90deg,transparent,rgba(255,255,255,.05),transparent)]" />
                <div className="absolute top-[26%] h-[48%] w-[14%] -translate-x-[220%] rotate-[10deg] rounded-full bg-[#c9aa92]/90 shadow-[inset_0_-25px_24px_rgba(0,0,0,.15)]" />
                <div className="absolute top-[26%] h-[48%] w-[14%] translate-x-[220%] rotate-[-10deg] rounded-full bg-[#c9aa92]/90 shadow-[inset_0_-25px_24px_rgba(0,0,0,.15)]" />
                <div className="absolute bottom-[1%] h-[36%] w-[15%] -translate-x-[72%] rounded-b-full bg-[#171720]" />
                <div className="absolute bottom-[1%] h-[36%] w-[15%] translate-x-[72%] rounded-b-full bg-[#171720]" />
              </>
            )}

            <div className="relative aspect-square w-[min(92vw,620px)] max-w-[760px] overflow-visible sm:w-[min(62vw,760px)] xl:w-[min(55vw,820px)]">
              <div
                className="absolute inset-0"
                style={{
                  transform: `scale(${visualScale})`,
                  transformOrigin: "center",
                }}
              >
                {generatedMockupUrl ? (
                  <img
                    src={generatedMockupUrl}
                    alt={`${productId} generated ${data.side}`}
                    draggable={false}
                    className="absolute inset-0 h-full w-full select-none object-contain drop-shadow-[0_45px_55px_rgba(0,0,0,.55)] sm:drop-shadow-[0_55px_65px_rgba(0,0,0,.55)]"
                  />
                ) : data.mockupUrl ? (
                  <>
                    <img
                      src={data.mockupUrl}
                      alt={`${productId} ${data.side}`}
                      draggable={false}
                      className="absolute inset-0 h-full w-full select-none object-contain drop-shadow-[0_45px_55px_rgba(0,0,0,.55)] sm:drop-shadow-[0_55px_65px_rgba(0,0,0,.55)]"
                    />
                    <div
                      className={`absolute inset-0 ${dark ? "opacity-85" : "opacity-65"}`}
                      style={{
                        backgroundColor: color,
                        mixBlendMode: dark ? "normal" : "multiply",
                        WebkitMaskImage: `url(${data.mockupUrl})`,
                        maskImage: `url(${data.mockupUrl})`,
                        WebkitMaskSize: "contain",
                        maskSize: "contain",
                        WebkitMaskRepeat: "no-repeat",
                        maskRepeat: "no-repeat",
                        WebkitMaskPosition: "center",
                        maskPosition: "center",
                      }}
                    />
                  </>
                ) : (
                  <div
                    className="absolute left-1/2 top-1/2 h-[72%] w-[54%] -translate-x-1/2 -translate-y-1/2 rounded-[28%_28%_16%_16%] shadow-[0_50px_70px_rgba(0,0,0,.55),inset_0_1px_0_rgba(255,255,255,.16)]"
                    style={{ backgroundColor: color }}
                  />
                )}
              </div>

              {!generatedMockupUrl && (
                <div
                  className="absolute z-20 overflow-hidden"
                  style={{
                    left: `${(data.safeArea.x / MOCKUP_AREA.width) * 100}%`,
                    top: `${(data.safeArea.y / MOCKUP_AREA.height) * 100}%`,
                    width: `${(data.safeArea.width / MOCKUP_AREA.width) * 100}%`,
                    height: `${(data.safeArea.height / MOCKUP_AREA.height) * 100}%`,
                  }}
                >
                  {sorted.map((el) => (
                    <PreviewCleanElement key={el.id} el={el} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

export default memo(PreviewMockup);
