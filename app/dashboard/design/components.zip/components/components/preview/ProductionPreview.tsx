"use client";

import { memo, useMemo, useRef, useState } from "react";
import PreviewActions from "./PreviewActions";
import PreviewHeader from "./PreviewHeader";
import PreviewMockup from "./PreviewMockup";
import PreviewProductionData from "./PreviewProductionData";
import PreviewSides from "./PreviewSides";
import PreviewWarnings from "./PreviewWarnings";
import { usePreviewData } from "./hooks/usePreviewData";
import type { ProductionPreviewInput, PreviewSide } from "./types/preview";

function ProductionPreview({
  input,
  onClose,
  onSaveDesign,
}: {
  input: ProductionPreviewInput;
  onClose: () => void;
  onSaveDesign?: () => Promise<void> | void;
}) {
  const preview = usePreviewData(input);
  const [activeSide, setActiveSide] = useState<PreviewSide>(preview.activeSide);
  const captureRef = useRef<HTMLDivElement | null>(null);

  const current = useMemo(
    () => (activeSide === "back" ? preview.back : preview.front),
    [activeSide, preview.back, preview.front],
  );

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden text-white">
      <PreviewHeader status={preview.combinedStatus} onClose={onClose} />

      <div className="min-h-0 flex-1 overflow-y-auto px-2 py-2 sm:px-5 sm:py-5 xl:px-6">
        <div className="grid gap-3 xl:grid-cols-[minmax(0,1fr)_420px] 2xl:grid-cols-[minmax(0,1fr)_460px]">
          <div ref={captureRef} className="min-w-0">
            <PreviewMockup data={current} productId={preview.productId} color={preview.mockupColor} />
          </div>

          <aside className="min-w-0 space-y-3 xl:sticky xl:top-0 xl:self-start">
            <PreviewSides
              front={preview.front}
              back={preview.back}
              activeSide={activeSide}
              setActiveSide={setActiveSide}
            />
            <PreviewProductionData data={current} />
            <PreviewWarnings validation={current.validation} />
            <PreviewActions
              captureNode={captureRef}
              onSaveDesign={onSaveDesign}
              productId={preview.productId}
              side={activeSide}
            />
          </aside>
        </div>
      </div>
    </div>
  );
}

export default memo(ProductionPreview);
