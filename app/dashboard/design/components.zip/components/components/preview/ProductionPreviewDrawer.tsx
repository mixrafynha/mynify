"use client";

import dynamic from "next/dynamic";
import { memo, useEffect, useRef } from "react";
import type { ProductionPreviewInput } from "./types/preview";

const ProductionPreview = dynamic(() => import("./ProductionPreview"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center bg-[#070711] text-sm font-bold text-white/45">
      Loading production preview...
    </div>
  ),
});

function ProductionPreviewDrawer({
  open,
  input,
  onClose,
  onSaveDesign,
}: {
  open: boolean;
  input: ProductionPreviewInput;
  onClose: () => void;
  onSaveDesign?: () => Promise<void> | void;
}) {
  const startY = useRef<number | null>(null);

  useEffect(() => {
    if (!open) return;

    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);

    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[1000] bg-black/76 text-white backdrop-blur-xl"
      role="dialog"
      aria-modal="true"
    >
      <button
        type="button"
        aria-label="Close preview"
        onClick={onClose}
        className="absolute inset-0 hidden cursor-default lg:block"
      />

      <div
        className="absolute inset-x-0 bottom-0 h-[94dvh] max-h-[94dvh] overflow-hidden rounded-t-[22px] border border-white/10 bg-[#070711] shadow-[0_-28px_100px_rgba(0,0,0,.72)] sm:rounded-t-[28px] md:inset-3 md:h-auto md:max-h-none md:rounded-[30px] xl:inset-5 xl:rounded-[34px]"
        onTouchStart={(event) => {
          startY.current = event.touches[0]?.clientY ?? null;
        }}
        onTouchEnd={(event) => {
          if (startY.current === null) return;
          const endY = event.changedTouches[0]?.clientY ?? startY.current;
          if (endY - startY.current > 110) onClose();
          startY.current = null;
        }}
      >
        <div className="mx-auto mt-2 h-1 w-12 rounded-full bg-white/24 md:hidden" />
        <ProductionPreview input={input} onClose={onClose} onSaveDesign={onSaveDesign} />
      </div>
    </div>
  );
}

export default memo(ProductionPreviewDrawer);
