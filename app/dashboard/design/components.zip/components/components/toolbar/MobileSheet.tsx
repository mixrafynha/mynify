"use client";

import { memo, useCallback, useMemo, useState } from "react";
import { X, ChevronUp, ChevronDown } from "lucide-react";

import TemplatesPanel from "./panels/TemplatesPanel";
import TextPanel from "./panels/TextPanel";
import UploadPanel from "./panels/UploadPanel";
import StickersPanel from "./panels/StickersPanel";
import IconsPanel from "./panels/IconsPanel";
import ImageTemplatesPanel from "./panels/ImageTemplatesPanel";
import Assets3DPanel from "./panels/Assets3DPanel";
import AiPanel from "./panels/AiPanel";
import LayersPanel from "./panels/LayersPanel";

type SheetSize = "mid" | "full";

const SHEET_HEIGHTS: Record<SheetSize, string> = {
  mid: "58dvh",
  full: "100dvh",
};

const TITLES: Record<string, string> = {
  ai: "AI Studio",
  templates: "Templates",
  text: "Text",
  upload: "Upload",
  stickers: "Stickers",
  icons: "Elements",
  images: "Images",
  assets3d: "3D Assets",
  layers: "Layers",
};

type MobileSheetProps = {
  open: boolean;
  panel: string;
  setOpen: (value: boolean) => void;
  selected?: any;
  onUpload?: (file: File) => void;
  onAddText?: () => void;
  createElement?: (element: any) => void;
  updateSelected?: (patch: any) => void;
  deleteSelected?: () => void;
  elements?: any[];
  updateElement?: (id: string, patch: any) => void;
  deleteElement?: (id: string) => void;
  setSelectedId?: (id: string | null) => void;
  setSelectedElement?: (el: any | null) => void;
};

function MobileSheet({
  open,
  panel,
  setOpen,
  selected,
  onUpload,
  onAddText,
  createElement,
  elements = [],
  updateElement,
  deleteElement,
  setSelectedId,
  setSelectedElement,
}: MobileSheetProps) {
  const [sheetSize, setSheetSize] = useState<SheetSize>("mid");
  const close = useCallback(() => setOpen(false), [setOpen]);

  const createAndClose = useCallback(
    (element: any) => {
      createElement?.(element);
      if (panel === "ai" || panel === "images" || panel === "assets3d") setOpen(false);
    },
    [createElement, panel, setOpen]
  );

  const content = useMemo(() => {
    if (panel === "templates") return <TemplatesPanel createElement={createElement} />;
    if (panel === "text") return <TextPanel createElement={createElement} onAddText={onAddText} />;
    if (panel === "upload") return <UploadPanel onUpload={onUpload} />;
    if (panel === "stickers") return <StickersPanel createElement={createElement} />;
    if (panel === "icons") return <IconsPanel createElement={createElement} />;
    if (panel === "images") return <ImageTemplatesPanel createElement={createAndClose} />;
    if (panel === "assets3d") return <Assets3DPanel createElement={createAndClose} />;
    if (panel === "ai") return <AiPanel createElement={createAndClose} />;
    if (panel === "layers") return <LayersPanel elements={elements} selected={selected} setSelectedId={setSelectedId} setSelectedElement={setSelectedElement} updateElement={updateElement} deleteElement={deleteElement} />;
    return <EmptyState />;
  }, [panel, selected, onUpload, onAddText, createElement, createAndClose, elements, updateElement, deleteElement, setSelectedId, setSelectedElement]);

  if (!open) return null;

  return (
    <>
      <button type="button" aria-label="Close panel overlay" onClick={close} className="fixed inset-0 z-30 bg-black/45 backdrop-blur-[2px] md:hidden" />

      <section
        className="fixed inset-x-0 bottom-0 z-40 md:hidden overflow-hidden rounded-t-[30px] border-t border-cyan-300/15 bg-[#070817]/98 text-white shadow-[0_-24px_80px_rgba(0,0,0,.42)] ring-1 ring-violet-400/15 backdrop-blur-2xl transition-[height] duration-150 ease-out"
        style={{ height: SHEET_HEIGHTS[sheetSize], paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="flex h-full flex-col overflow-hidden">
          <header className="shrink-0 border-b border-white/10 bg-gradient-to-r from-[#0b0b1d] via-[#111026] to-[#071522] px-4 py-2">
            <button
              type="button"
              onClick={() => setSheetSize((v) => (v === "full" ? "mid" : "full"))}
              className="mx-auto mb-1 flex h-7 w-28 items-center justify-center rounded-full bg-white/[0.07] text-cyan-100 active:scale-95"
              aria-label="Resize panel"
            >
              {sheetSize === "full" ? <ChevronDown size={18} /> : <ChevronUp size={18} />}
            </button>

            <div className="flex items-center justify-between gap-3">
              <div className="min-w-0">
                <h2 className="truncate text-sm font-black tracking-[-0.02em]">{TITLES[panel] || "Tools"}</h2>
                <p className="text-[11px] font-medium text-slate-500">Fast editor tools</p>
              </div>

              <button type="button" onClick={close} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/[0.08] text-cyan-100 active:scale-95" aria-label="Close panel">
                <X size={17} />
              </button>
            </div>
          </header>

          <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 py-3 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {content}
          </div>
        </div>
      </section>
    </>
  );
}

function EmptyState() {
  return <div className="py-10 text-center text-sm font-semibold text-slate-500">Choose a tool.</div>;
}

export default memo(MobileSheet);
