"use client";

import { useEffect, useState, useCallback } from "react";
import { calculateDPI, getQualityLevel } from "../engine/dpi";

interface DPIBadgeProps {
  element: any;
  printBox?: { width: number; height: number };
  gelatoPrintSize?: { widthMm: number; heightMm: number };
}

export default function DPIBadge({ element, printBox, gelatoPrintSize }: DPIBadgeProps) {
  const [dpi, setDpi] = useState<number | null>(null);
  const [quality, setQuality] = useState<"excellent" | "good" | "poor" | null>(null);
  const [naturalDimensions, setNaturalDimensions] = useState<{ width: number; height: number } | null>(null);
  const [loading, setLoading] = useState(false);

  const MM_PER_INCH = 25.4;

  // Carrega as dimensões naturais da imagem
  const loadNaturalDimensions = useCallback((src: string): Promise<{ width: number; height: number }> => {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
      img.onerror = reject;
      img.src = src;
    });
  }, []);

  // Carrega dimensões naturais
  useEffect(() => {
    if (!element || element.type !== "image") return;
    
    if (element.meta?.naturalWidth && element.meta?.naturalHeight) {
      setNaturalDimensions({
        width: element.meta.naturalWidth,
        height: element.meta.naturalHeight,
      });
      return;
    }
    
    if (element.src && !naturalDimensions && !loading) {
      setLoading(true);
      loadNaturalDimensions(element.src)
        .then((dims) => {
          setNaturalDimensions(dims);
          setLoading(false);
        })
        .catch(() => setLoading(false));
    }
  }, [element, naturalDimensions, loading, loadNaturalDimensions]);

  // Calcula DPI baseado no tamanho real de impressão do Gelato
  const calculateGelatoDPI = useCallback(() => {
    if (!naturalDimensions || !element?.width || !printBox?.width || !gelatoPrintSize?.widthMm) {
      return null;
    }

    // Tamanho do print box em pixels (1024)
    const printBoxWidthPx = printBox.width;
    
    // Tamanho real de impressão do produto em mm (vindo do Gelato)
    const productPrintWidthMm = gelatoPrintSize.widthMm;
    
    // Proporção da imagem em relação ao print box
    const imageRatio = element.width / printBoxWidthPx;
    
    // Tamanho real da imagem na impressão em mm
    const imagePrintWidthMm = productPrintWidthMm * imageRatio;
    
    // Converter para polegadas
    const imagePrintWidthInches = imagePrintWidthMm / MM_PER_INCH;
    
    // Calcular DPI final
    const calculatedDPI = Math.round(naturalDimensions.width / imagePrintWidthInches);
    
    return calculatedDPI;
  }, [naturalDimensions, element?.width, printBox, gelatoPrintSize]);

  // Recalcula DPI quando os parâmetros mudarem
  useEffect(() => {
    const calculatedDpi = calculateGelatoDPI();
    
    if (calculatedDpi !== null) {
      const calculatedQuality = getQualityLevel(calculatedDpi);
      setDpi(calculatedDpi);
      setQuality(calculatedQuality);
    }
  }, [calculateGelatoDPI]);

  if (loading || !dpi || !quality) return null;

  const getColor = () => {
    switch (quality) {
      case "excellent": return "bg-green-500/90 text-white";
      case "good": return "bg-yellow-500/90 text-black";
      case "poor": return "bg-red-500/90 text-white";
      default: return "bg-gray-500/90 text-white";
    }
  };

  return (
    <div
      className={`absolute top-1 left-1 z-30 rounded-md px-1.5 py-0.5 text-[10px] font-bold shadow-md ${getColor()}`}
      title={`DPI: ${dpi} - ${quality === "excellent" ? "Excelente para impressão" : quality === "good" ? "Mínimo recomendado (150 DPI)" : "Baixa qualidade (<150 DPI)"}`}
    >
      {dpi} DPI
    </div>
  );
}